<?php
/**
 * 测试接口 - 用于检查服务状态
 */

// 引入依赖
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/common.php';
require_once __DIR__ . '/../lib/DataokeAdapter.php';

// 只允许GET请求
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    apiResponse(405, '只支持GET请求');
}

try {
    // 获取大淘客适配器
    $adapter = getDataokeAdapter();
    
    // 测试连接
    $result = $adapter->testConnection();
    
    if ($result['success']) {
        $responseData = [
            'service_status' => 'running',
            'dataoke_status' => 'connected',
            'server_time' => date('Y-m-d H:i:s'),
            'php_version' => PHP_VERSION,
            'cache_status' => is_writable(CACHE_CONFIG['path']) ? 'writable' : 'readonly',
            'log_status' => is_writable(LOG_CONFIG['path']) ? 'writable' : 'readonly',
            'dataoke_info' => [
                'app_key' => DATAOKE_CONFIG['app_key'],
                'version' => DATAOKE_CONFIG['version'],
                'test_time' => $result['data']['test_time'] ?? date('Y-m-d H:i:s')
            ]
        ];
        
        logInfo('服务测试成功');
        apiResponse(0, '服务运行正常', $responseData);
    } else {
        logError('大淘客连接测试失败: ' . $result['message']);
        
        $responseData = [
            'service_status' => 'running',
            'dataoke_status' => 'disconnected',
            'server_time' => date('Y-m-d H:i:s'),
            'error' => $result['message']
        ];
        
        apiResponse(500, '大淘客连接失败', $responseData);
    }
    
} catch (Exception $e) {
    logError('测试接口异常: ' . $e->getMessage(), $e->getTraceAsString());
    
    $responseData = [
        'service_status' => 'error',
        'server_time' => date('Y-m-d H:i:s'),
        'error' => $e->getMessage()
    ];
    
    apiResponse(500, '服务异常', $responseData);
}
?>
