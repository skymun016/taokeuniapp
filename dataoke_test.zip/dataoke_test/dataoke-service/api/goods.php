<?php
/**
 * 商品相关API接口
 */

// 引入依赖
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/common.php';
require_once __DIR__ . '/../lib/DataokeAdapter.php';

// 获取请求参数
$action = getParam('action', 'list');
$method = $_SERVER['REQUEST_METHOD'];

// 只允许GET请求
if ($method !== 'GET') {
    apiResponse(405, '只支持GET请求');
}

// 创建缓存实例
$cache = new SimpleCache();

// 根据action分发处理
switch ($action) {
    case 'list':
        handleGoodsList($cache);
        break;
        
    case 'detail':
        handleGoodsDetail($cache);
        break;
        
    default:
        apiResponse(400, '无效的action参数');
}

/**
 * 处理商品列表请求
 * @param SimpleCache $cache 缓存实例
 */
function handleGoodsList($cache) {
    // 获取请求参数
    $page = getParam('page', 1, 'int');
    $pageSize = getParam('pageSize', API_CONFIG['default_page_size'], 'int');
    $categoryId = getParam('categoryId', '', 'string');
    $keyword = getParam('keyword', '', 'string');
    $sort = getParam('sort', 0, 'int');
    $minCoupon = getParam('minCoupon', 0, 'int');
    $tmall = getParam('tmall', 0, 'int');
    
    // 参数验证
    if ($page < 1) $page = 1;
    if ($pageSize < 1) $pageSize = API_CONFIG['default_page_size'];
    if ($pageSize > API_CONFIG['max_page_size']) $pageSize = API_CONFIG['max_page_size'];
    
    // 构建缓存键
    $cacheKey = 'goods_list_' . md5(serialize([
        'page' => $page,
        'pageSize' => $pageSize,
        'categoryId' => $categoryId,
        'keyword' => $keyword,
        'sort' => $sort,
        'minCoupon' => $minCoupon,
        'tmall' => $tmall
    ]));
    
    // 尝试从缓存获取
    $cachedData = $cache->get($cacheKey);
    if ($cachedData !== null) {
        logInfo('商品列表缓存命中', ['page' => $page, 'pageSize' => $pageSize]);
        apiResponse(0, 'success', $cachedData);
    }
    
    try {
        // 获取大淘客适配器
        $adapter = getDataokeAdapter();
        
        // 构建请求参数
        $params = [
            'pageId' => $page,
            'pageSize' => $pageSize,
            'sort' => $sort
        ];
        
        // 添加可选参数
        if (!empty($categoryId)) {
            $params['cids'] = $categoryId;
        }
        
        if (!empty($keyword)) {
            // 如果有关键词，使用搜索接口
            $result = $adapter->searchGoods($keyword, $params);
        } else {
            // 否则使用商品列表接口
            if ($minCoupon > 0) {
                $params['couponPriceLowerLimit'] = $minCoupon;
            }
            if ($tmall > 0) {
                $params['tmall'] = 1;
            }
            
            $result = $adapter->getGoodsList($params);
        }
        
        if ($result['success']) {
            // 转换数据格式
            $goodsList = convertData($result['data']['list'], 'goods');
            
            $responseData = [
                'list' => $goodsList,
                'total' => $result['data']['totalNum'] ?? count($goodsList),
                'page' => $page,
                'pageSize' => $pageSize,
                'hasMore' => count($goodsList) >= $pageSize
            ];
            
            // 缓存结果
            $cache->set($cacheKey, $responseData, CACHE_CONFIG['expire']['goods_list']);
            
            logInfo('商品列表获取成功', [
                'page' => $page,
                'pageSize' => $pageSize,
                'count' => count($goodsList)
            ]);
            
            apiResponse(0, 'success', $responseData);
        } else {
            logError('商品列表获取失败: ' . $result['message']);
            apiResponse(500, '获取商品列表失败: ' . $result['message']);
        }
        
    } catch (Exception $e) {
        logError('商品列表接口异常: ' . $e->getMessage(), $e->getTraceAsString());
        apiResponse(500, '服务器内部错误');
    }
}

/**
 * 处理商品详情请求
 * @param SimpleCache $cache 缓存实例
 */
function handleGoodsDetail($cache) {
    // 验证必需参数
    $goodsId = getParam('id', '', 'string');
    if (empty($goodsId)) {
        apiResponse(400, '缺少商品ID参数');
    }
    
    // 构建缓存键
    $cacheKey = 'goods_detail_' . $goodsId;
    
    // 尝试从缓存获取
    $cachedData = $cache->get($cacheKey);
    if ($cachedData !== null) {
        logInfo('商品详情缓存命中', ['goodsId' => $goodsId]);
        apiResponse(0, 'success', $cachedData);
    }
    
    try {
        // 获取大淘客适配器
        $adapter = getDataokeAdapter();
        
        // 获取商品详情
        $result = $adapter->getGoodsDetails($goodsId);
        
        if ($result['success']) {
            // 转换数据格式
            $goodsDetail = convertSingleData($result['data'], DATA_MAPPING['goods']);
            
            // 添加额外字段
            $goodsDetail['pics'] = [];
            if (!empty($result['data']['mainPic'])) {
                $goodsDetail['pics'][] = $result['data']['mainPic'];
            }
            if (!empty($result['data']['video'])) {
                $goodsDetail['video'] = $result['data']['video'];
            }
            if (!empty($result['data']['desc'])) {
                $goodsDetail['desc'] = $result['data']['desc'];
            }
            
            // 缓存结果
            $cache->set($cacheKey, $goodsDetail, CACHE_CONFIG['expire']['goods_detail']);
            
            logInfo('商品详情获取成功', ['goodsId' => $goodsId]);
            
            apiResponse(0, 'success', $goodsDetail);
        } else {
            logError('商品详情获取失败: ' . $result['message'], ['goodsId' => $goodsId]);
            apiResponse(500, '获取商品详情失败: ' . $result['message']);
        }
        
    } catch (Exception $e) {
        logError('商品详情接口异常: ' . $e->getMessage(), $e->getTraceAsString());
        apiResponse(500, '服务器内部错误');
    }
}
?>
