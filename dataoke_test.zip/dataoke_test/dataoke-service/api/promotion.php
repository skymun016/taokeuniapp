<?php
/**
 * 推广相关API接口 - 淘口令生成和推广链接
 */

// 引入依赖
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/common.php';
require_once __DIR__ . '/../lib/DataokeAdapter.php';

// 获取请求参数
$action = getParam('action', 'tkl');
$method = $_SERVER['REQUEST_METHOD'];

// 只允许GET和POST请求
if (!in_array($method, ['GET', 'POST'])) {
    apiResponse(405, '只支持GET和POST请求');
}

// 创建缓存实例
$cache = new SimpleCache();

// 根据action分发处理
switch ($action) {
    case 'tkl':
        handleCreateTkl($cache);
        break;
        
    case 'link':
        handlePrivilegeLink($cache);
        break;
        
    default:
        apiResponse(400, '无效的action参数');
}

/**
 * 处理淘口令生成请求
 * @param SimpleCache $cache 缓存实例
 */
function handleCreateTkl($cache) {
    // 验证必需参数
    $text = getParam('text', '', 'string');
    $url = getParam('url', '', 'string');
    
    if (empty($text)) {
        apiResponse(400, '缺少text参数（淘口令文本）');
    }
    
    if (empty($url)) {
        apiResponse(400, '缺少url参数（商品链接）');
    }
    
    // 构建缓存键
    $cacheKey = 'tkl_' . md5($text . $url);
    
    // 尝试从缓存获取
    $cachedData = $cache->get($cacheKey);
    if ($cachedData !== null) {
        logInfo('淘口令缓存命中', ['text' => $text]);
        apiResponse(0, 'success', $cachedData);
    }
    
    try {
        // 获取大淘客适配器
        $adapter = getDataokeAdapter();
        
        // 生成淘口令
        $result = $adapter->createTkl($text, $url);
        
        if ($result['success']) {
            $responseData = [
                'tkl' => $result['data']['tkl'] ?? '',
                'text' => $text,
                'url' => $url,
                'created_time' => date('Y-m-d H:i:s')
            ];
            
            // 缓存结果（淘口令缓存1小时）
            $cache->set($cacheKey, $responseData, 3600);
            
            logInfo('淘口令生成成功', ['text' => $text]);
            
            apiResponse(0, 'success', $responseData);
        } else {
            logError('淘口令生成失败: ' . $result['message'], ['text' => $text, 'url' => $url]);
            apiResponse(500, '淘口令生成失败: ' . $result['message']);
        }
        
    } catch (Exception $e) {
        logError('淘口令生成接口异常: ' . $e->getMessage(), $e->getTraceAsString());
        apiResponse(500, '服务器内部错误');
    }
}

/**
 * 处理推广链接生成请求
 * @param SimpleCache $cache 缓存实例
 */
function handlePrivilegeLink($cache) {
    // 验证必需参数
    $goodsId = getParam('goodsId', '', 'string');
    $couponId = getParam('couponId', '', 'string');
    $channelId = getParam('channelId', 'common', 'string');
    
    if (empty($goodsId)) {
        apiResponse(400, '缺少goodsId参数（商品ID）');
    }
    
    // 构建缓存键
    $cacheKey = 'privilege_link_' . md5($goodsId . $couponId . $channelId);
    
    // 尝试从缓存获取
    $cachedData = $cache->get($cacheKey);
    if ($cachedData !== null) {
        logInfo('推广链接缓存命中', ['goodsId' => $goodsId]);
        apiResponse(0, 'success', $cachedData);
    }
    
    try {
        // 获取大淘客适配器
        $adapter = getDataokeAdapter();
        
        // 构建参数 - 使用基础参数即可
        $params = [
            'goodsId' => $goodsId,
            'pid' => DATAOKE_CONFIG['pid']
        ];

        // 只有在明确提供时才添加可选参数
        if (!empty($couponId)) {
            $params['couponId'] = $couponId;
        }

        if (!empty($channelId) && $channelId !== 'common') {
            $params['channelId'] = $channelId;
        }
        
        // 生成推广链接
        $result = $adapter->getPrivilegeLink($params);
        
        if ($result['success']) {
            $responseData = [
                'goods_id' => $goodsId,
                'coupon_id' => $couponId,
                'item_url' => $result['data']['itemUrl'] ?? '',
                'short_url' => $result['data']['shortUrl'] ?? '',
                'kuaizhan_url' => $result['data']['kuaiZhanUrl'] ?? '',
                'tpwd' => $result['data']['tpwd'] ?? '',
                'long_tpwd' => $result['data']['longTpwd'] ?? '',
                'commission_rate' => $result['data']['maxCommissionRate'] ?? '',
                'created_time' => date('Y-m-d H:i:s')
            ];
            
            // 缓存结果（推广链接缓存2小时）
            $cache->set($cacheKey, $responseData, 7200);
            
            logInfo('推广链接生成成功', ['goodsId' => $goodsId]);
            
            apiResponse(0, 'success', $responseData);
        } else {
            logError('推广链接生成失败: ' . $result['message'], ['goodsId' => $goodsId]);
            apiResponse(500, '推广链接生成失败: ' . $result['message']);
        }
        
    } catch (Exception $e) {
        logError('推广链接生成接口异常: ' . $e->getMessage(), $e->getTraceAsString());
        apiResponse(500, '服务器内部错误');
    }
}
?>
