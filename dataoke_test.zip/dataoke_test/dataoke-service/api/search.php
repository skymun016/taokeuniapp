<?php
/**
 * 搜索相关API接口
 */

// 引入依赖
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/common.php';
require_once __DIR__ . '/../lib/DataokeAdapter.php';

// 只允许GET请求
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    apiResponse(405, '只支持GET请求');
}

// 获取请求参数
$keyword = getParam('keyword', '', 'string');
$page = getParam('page', 1, 'int');
$pageSize = getParam('pageSize', API_CONFIG['default_page_size'], 'int');
$sort = getParam('sort', 0, 'int');

// 验证必需参数
if (empty($keyword)) {
    apiResponse(400, '缺少搜索关键词');
}

// 参数验证
if ($page < 1) $page = 1;
if ($pageSize < 1) $pageSize = API_CONFIG['default_page_size'];
if ($pageSize > API_CONFIG['max_page_size']) $pageSize = API_CONFIG['max_page_size'];

// 创建缓存实例
$cache = new SimpleCache();

// 构建缓存键
$cacheKey = 'search_' . md5(serialize([
    'keyword' => $keyword,
    'page' => $page,
    'pageSize' => $pageSize,
    'sort' => $sort
]));

// 尝试从缓存获取
$cachedData = $cache->get($cacheKey);
if ($cachedData !== null) {
    logInfo('搜索结果缓存命中', ['keyword' => $keyword, 'page' => $page]);
    apiResponse(0, 'success', $cachedData);
}

try {
    // 获取大淘客适配器
    $adapter = getDataokeAdapter();
    
    // 构建搜索参数
    $params = [
        'pageId' => $page,
        'pageSize' => $pageSize,
        'sort' => $sort
    ];
    
    // 执行搜索
    $result = $adapter->searchGoods($keyword, $params);
    
    if ($result['success']) {
        // 转换数据格式
        $goodsList = convertData($result['data']['list'], 'goods');
        
        $responseData = [
            'list' => $goodsList,
            'total' => $result['data']['totalNum'] ?? count($goodsList),
            'page' => $page,
            'pageSize' => $pageSize,
            'keyword' => $keyword,
            'hasMore' => count($goodsList) >= $pageSize
        ];
        
        // 缓存结果
        $cache->set($cacheKey, $responseData, CACHE_CONFIG['expire']['search']);
        
        logInfo('搜索成功', [
            'keyword' => $keyword,
            'page' => $page,
            'count' => count($goodsList)
        ]);
        
        apiResponse(0, 'success', $responseData);
    } else {
        logError('搜索失败: ' . $result['message'], ['keyword' => $keyword]);
        apiResponse(500, '搜索失败: ' . $result['message']);
    }
    
} catch (Exception $e) {
    logError('搜索接口异常: ' . $e->getMessage(), $e->getTraceAsString());
    apiResponse(500, '服务器内部错误');
}
?>
