<?php
/**
 * 管理后台配置文件
 */

/**
 * 获取动态基础路径
 * @return string
 */
function getBasePath() {
    $scriptName = $_SERVER['SCRIPT_NAME'];
    $basePath = dirname(dirname($scriptName));
    return $basePath === '/' ? '' : $basePath;
}

/**
 * 获取管理后台基础URL
 * @return string
 */
function getAdminBaseUrl() {
    return getBasePath() . '/admin';
}

/**
 * 获取资源基础URL
 * @return string
 */
function getAssetsBaseUrl() {
    return getBasePath() . '/admin/assets';
}

// 管理后台基础配置
define('ADMIN_CONFIG', [
    'title' => '大淘客服务端管理后台',
    'version' => '1.0.0',
    'session_timeout' => 3600, // Session超时时间（秒）
    'max_login_attempts' => 5,  // 最大登录尝试次数
    'lockout_time' => 900,      // 锁定时间（秒）
    'password_min_length' => 6, // 最小密码长度
    'enable_logs' => true,      // 是否启用操作日志
    'logs_retention_days' => 30 // 日志保留天数
]);

// 默认管理员账户配置
define('DEFAULT_ADMIN', [
    'username' => 'admin',
    'password' => 'admin123', // 首次登录后会要求修改
    'email' => 'admin@example.com',
    'role' => 'super_admin',
    'created_time' => date('Y-m-d H:i:s')
]);

// 权限配置
define('ADMIN_PERMISSIONS', [
    'super_admin' => [
        'dashboard' => true,
        'config_view' => true,
        'config_edit' => true,
        'goods_view' => true,
        'goods_manage' => true,
        'logs_view' => true,
        'logs_manage' => true,
        'settings_view' => true,
        'settings_edit' => true,
        'user_manage' => true
    ],
    'admin' => [
        'dashboard' => true,
        'config_view' => true,
        'config_edit' => false,
        'goods_view' => true,
        'goods_manage' => true,
        'logs_view' => true,
        'logs_manage' => false,
        'settings_view' => true,
        'settings_edit' => false,
        'user_manage' => false
    ],
    'viewer' => [
        'dashboard' => true,
        'config_view' => true,
        'config_edit' => false,
        'goods_view' => true,
        'goods_manage' => false,
        'logs_view' => true,
        'logs_manage' => false,
        'settings_view' => false,
        'settings_edit' => false,
        'user_manage' => false
    ]
]);

// 菜单配置 - 使用动态路径
$adminBaseUrl = getAdminBaseUrl();
define('ADMIN_MENU', [
    [
        'id' => 'dashboard',
        'title' => '仪表板',
        'icon' => 'dashboard',
        'url' => $adminBaseUrl . '/dashboard',
        'permission' => 'dashboard'
    ],
    [
        'id' => 'config',
        'title' => '配置管理',
        'icon' => 'settings',
        'url' => $adminBaseUrl . '/config',
        'permission' => 'config_view'
    ],
    [
        'id' => 'goods',
        'title' => '商品管理',
        'icon' => 'shopping-cart',
        'url' => $adminBaseUrl . '/goods',
        'permission' => 'goods_view'
    ],
    [
        'id' => 'logs',
        'title' => '日志管理',
        'icon' => 'file-text',
        'url' => $adminBaseUrl . '/logs',
        'permission' => 'logs_view'
    ],
    [
        'id' => 'settings',
        'title' => '系统设置',
        'icon' => 'cog',
        'url' => $adminBaseUrl . '/settings',
        'permission' => 'settings_view'
    ]
]);

// 数据存储路径
define('ADMIN_DATA_PATH', __DIR__ . '/../data/');

// 确保数据目录存在
if (!is_dir(ADMIN_DATA_PATH)) {
    mkdir(ADMIN_DATA_PATH, 0755, true);
}

// 管理员用户文件路径
define('ADMIN_USERS_FILE', ADMIN_DATA_PATH . 'admin_users.json');

// 操作日志文件路径
define('ADMIN_LOGS_FILE', ADMIN_DATA_PATH . 'admin_logs.json');

// 登录尝试记录文件路径
define('LOGIN_ATTEMPTS_FILE', ADMIN_DATA_PATH . 'login_attempts.json');
?>
