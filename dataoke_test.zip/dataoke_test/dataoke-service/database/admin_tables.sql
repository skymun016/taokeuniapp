-- 大淘客管理后台数据库表结构
-- 创建时间: 2025-07-16
-- 说明: 管理后台用户、配置和日志表

-- 1. 管理员用户表
CREATE TABLE `dtk_admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(255) NOT NULL COMMENT '密码哈希',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `role` enum('super_admin','admin','viewer') NOT NULL DEFAULT 'viewer' COMMENT '用户角色',
  `status` enum('active','inactive','locked') NOT NULL DEFAULT 'active' COMMENT '用户状态',
  `last_login` datetime DEFAULT NULL COMMENT '最后登录时间',
  `login_count` int(11) DEFAULT 0 COMMENT '登录次数',
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_role` (`role`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员用户表';

-- 2. 管理后台配置表
CREATE TABLE `dtk_admin_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `config_key` varchar(100) NOT NULL COMMENT '配置键',
  `config_value` text COMMENT '配置值',
  `config_type` enum('string','number','boolean','json') NOT NULL DEFAULT 'string' COMMENT '配置类型',
  `description` varchar(500) DEFAULT NULL COMMENT '配置描述',
  `is_encrypted` tinyint(1) DEFAULT 0 COMMENT '是否加密存储',
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理后台配置表';

-- 3. 操作日志表
CREATE TABLE `dtk_admin_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `action` varchar(50) NOT NULL COMMENT '操作类型',
  `description` varchar(500) NOT NULL COMMENT '操作描述',
  `request_data` text COMMENT '请求数据JSON',
  `response_data` text COMMENT '响应数据JSON',
  `ip_address` varchar(45) NOT NULL COMMENT 'IP地址',
  `user_agent` text COMMENT '用户代理',
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_username` (`username`),
  KEY `idx_action` (`action`),
  KEY `idx_created_time` (`created_time`),
  KEY `idx_ip_address` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志表';

-- 4. 登录尝试记录表
CREATE TABLE `dtk_login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '记录ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `ip_address` varchar(45) NOT NULL COMMENT 'IP地址',
  `success` tinyint(1) NOT NULL COMMENT '是否成功',
  `failure_reason` varchar(200) DEFAULT NULL COMMENT '失败原因',
  `user_agent` text COMMENT '用户代理',
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_username` (`username`),
  KEY `idx_ip_address` (`ip_address`),
  KEY `idx_created_time` (`created_time`),
  KEY `idx_success` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='登录尝试记录表';

-- 5. 大淘客API配置表（扩展现有配置）
CREATE TABLE `dtk_dataoke_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `config_name` varchar(100) NOT NULL COMMENT '配置名称',
  `app_key` varchar(100) NOT NULL COMMENT '大淘客AppKey',
  `app_secret` varchar(100) NOT NULL COMMENT '大淘客AppSecret',
  `pid` varchar(50) NOT NULL COMMENT '推广位PID',
  `version` varchar(20) DEFAULT 'v1.2.4' COMMENT 'API版本',
  `api_url` varchar(200) DEFAULT 'https://openapi.dataoke.com/api/' COMMENT 'API接口地址',
  `timeout` int(11) DEFAULT 30 COMMENT '请求超时时间(秒)',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active' COMMENT '配置状态',
  `is_default` tinyint(1) DEFAULT 0 COMMENT '是否默认配置',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注说明',
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_config_name` (`config_name`),
  KEY `idx_status` (`status`),
  KEY `idx_is_default` (`is_default`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='大淘客API配置表';

-- 插入默认管理员账户
INSERT INTO `dtk_admin_users` (`username`, `password`, `email`, `role`, `status`) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@example.com', 'super_admin', 'active');
-- 默认密码: admin123

-- 插入默认系统配置
INSERT INTO `dtk_admin_config` (`config_key`, `config_value`, `config_type`, `description`) VALUES
('admin_title', '大淘客服务端管理后台', 'string', '管理后台标题'),
('admin_version', '1.0.0', 'string', '管理后台版本'),
('session_timeout', '3600', 'number', 'Session超时时间（秒）'),
('max_login_attempts', '5', 'number', '最大登录尝试次数'),
('lockout_time', '900', 'number', '账户锁定时间（秒）'),
('password_min_length', '6', 'number', '最小密码长度'),
('enable_logs', '1', 'boolean', '是否启用操作日志'),
('logs_retention_days', '30', 'number', '日志保留天数'),
('cache_goods_list', '1800', 'number', '商品列表缓存时间（秒）'),
('cache_goods_detail', '3600', 'number', '商品详情缓存时间（秒）'),
('cache_category', '86400', 'number', '分类缓存时间（秒）'),
('cache_search', '900', 'number', '搜索结果缓存时间（秒）'),
('cors_allow_origin', '*', 'string', 'CORS允许的域名'),
('cors_allow_methods', 'GET, POST, OPTIONS', 'string', 'CORS允许的方法'),
('cors_allow_headers', 'Content-Type, Authorization, X-Requested-With', 'string', 'CORS允许的头部'),
('cors_allow_credentials', 'false', 'string', 'CORS是否允许凭证');

-- 插入默认大淘客配置
INSERT INTO `dtk_dataoke_config` (`config_name`, `app_key`, `app_secret`, `pid`, `version`, `status`, `is_default`, `remark`) VALUES
('默认配置', '68768ef94834a', 'f5a5707c8d7b69b8dbad1ec15506c3b1', 'mm_52162983_39758207_72877900030', 'v1.2.4', 'active', 1, '系统默认大淘客配置');

-- 创建索引优化查询性能
CREATE INDEX idx_admin_logs_user_action ON dtk_admin_logs(user_id, action);
CREATE INDEX idx_admin_logs_time_range ON dtk_admin_logs(created_time DESC);
CREATE INDEX idx_login_attempts_user_time ON dtk_login_attempts(username, created_time DESC);
CREATE INDEX idx_login_attempts_ip_time ON dtk_login_attempts(ip_address, created_time DESC);

-- 创建视图方便查询
CREATE VIEW v_admin_user_stats AS
SELECT 
    u.id,
    u.username,
    u.role,
    u.status,
    u.last_login,
    u.login_count,
    u.created_time,
    COUNT(l.id) as total_operations,
    MAX(l.created_time) as last_operation
FROM dtk_admin_users u
LEFT JOIN dtk_admin_logs l ON u.id = l.user_id
GROUP BY u.id;

CREATE VIEW v_login_failure_stats AS
SELECT 
    username,
    ip_address,
    COUNT(*) as failure_count,
    MAX(created_time) as last_failure,
    MIN(created_time) as first_failure
FROM dtk_login_attempts 
WHERE success = 0 
    AND created_time > DATE_SUB(NOW(), INTERVAL 1 DAY)
GROUP BY username, ip_address
HAVING failure_count >= 3;

-- 添加表注释
ALTER TABLE dtk_admin_users COMMENT = '管理员用户表 - 存储后台管理员账户信息';
ALTER TABLE dtk_admin_config COMMENT = '管理后台配置表 - 存储系统配置参数';
ALTER TABLE dtk_admin_logs COMMENT = '操作日志表 - 记录管理员操作历史';
ALTER TABLE dtk_login_attempts COMMENT = '登录尝试记录表 - 记录登录尝试和安全监控';
ALTER TABLE dtk_dataoke_config COMMENT = '大淘客API配置表 - 存储大淘客接口配置信息';
