<?php
$auth = AdminAuth::getInstance();
$canManage = $auth->hasPermission('goods_manage');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>商品管理 - <?php echo ADMIN_CONFIG['title']; ?></title>
    <link rel="stylesheet" href="/dataoke-service/admin/assets/css/admin.css">
</head>
<body>
    <?php include __DIR__ . '/layout/header.php'; ?>
    
    <div class="admin-container">
        <?php include __DIR__ . '/layout/sidebar.php'; ?>
        
        <main class="admin-main">
            <div class="page-header">
                <h1>商品管理</h1>
                <p>查看和管理大淘客商品数据</p>
            </div>
            
            <!-- 搜索和过滤 -->
            <div class="search-section">
                <form method="GET" class="search-form">
                    <div class="search-row">
                        <div class="search-group">
                            <input type="text" name="keyword" placeholder="搜索商品关键词..." 
                                   value="<?php echo htmlspecialchars($_GET['keyword'] ?? ''); ?>">
                        </div>
                        <div class="search-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="icon-search"></i>
                                搜索
                            </button>
                            <a href="<?php echo getAdminBaseUrl(); ?>/goods" class="btn btn-secondary">
                                <i class="icon-refresh-cw"></i>
                                重置
                            </a>
                            <?php if ($canManage): ?>
                                <button type="button" onclick="refreshGoods()" class="btn btn-info">
                                    <i class="icon-download"></i>
                                    刷新数据
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
            
            <?php if (isset($goodsData) && $goodsData['success']): ?>
                <!-- 商品列表 -->
                <div class="goods-section">
                    <div class="section-header">
                        <h2>商品列表</h2>
                        <div class="section-info">
                            <?php if (!empty($goodsData['keyword'])): ?>
                                <span class="search-info">搜索: "<?php echo htmlspecialchars($goodsData['keyword']); ?>"</span>
                            <?php endif; ?>
                            <span class="page-info">第 <?php echo $goodsData['page']; ?> 页</span>
                        </div>
                    </div>
                    
                    <div class="goods-grid">
                        <?php if (!empty($goodsData['data']['list'])): ?>
                            <?php foreach ($goodsData['data']['list'] as $goods): ?>
                                <div class="goods-card">
                                    <div class="goods-image">
                                        <img src="<?php echo htmlspecialchars($goods['pict_url'] ?? ''); ?>" 
                                             alt="<?php echo htmlspecialchars($goods['title'] ?? ''); ?>"
                                             onerror="this.src='/dataoke-service/admin/assets/images/no-image.png'">
                                        <?php if (!empty($goods['coupon_amount'])): ?>
                                            <div class="coupon-badge">
                                                券<?php echo $goods['coupon_amount']; ?>元
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="goods-content">
                                        <h3 class="goods-title" title="<?php echo htmlspecialchars($goods['title'] ?? ''); ?>">
                                            <?php echo htmlspecialchars(mb_substr($goods['title'] ?? '', 0, 50)); ?>
                                        </h3>
                                        
                                        <div class="goods-price">
                                            <span class="current-price">¥<?php echo number_format($goods['actual_price'] ?? 0, 2); ?></span>
                                            <?php if (!empty($goods['original_price']) && $goods['original_price'] > $goods['actual_price']): ?>
                                                <span class="original-price">¥<?php echo number_format($goods['original_price'], 2); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="goods-stats">
                                            <span class="sales">月销: <?php echo number_format($goods['month_sales'] ?? 0); ?></span>
                                            <span class="commission">佣金: <?php echo number_format($goods['commission_rate'] ?? 0, 2); ?>%</span>
                                        </div>
                                        
                                        <div class="goods-actions">
                                            <button onclick="viewGoodsDetail('<?php echo $goods['goods_id']; ?>')" 
                                                    class="btn btn-sm btn-info">
                                                <i class="icon-eye"></i>
                                                查看详情
                                            </button>
                                            <button onclick="copyGoodsLink('<?php echo $goods['goods_id']; ?>')" 
                                                    class="btn btn-sm btn-secondary">
                                                <i class="icon-copy"></i>
                                                复制链接
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="icon-package"></i>
                                <h3>暂无商品数据</h3>
                                <p>请尝试刷新数据或检查API配置</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- 分页 -->
                    <?php if (!empty($goodsData['data']['list'])): ?>
                        <div class="pagination">
                            <?php 
                            $currentPage = $goodsData['page'];
                            $keyword = $goodsData['keyword'];
                            $baseUrl = '/dataoke-service/admin/goods';
                            $queryParams = $keyword ? "?keyword=" . urlencode($keyword) : '';
                            ?>
                            
                            <?php if ($currentPage > 1): ?>
                                <a href="<?php echo $baseUrl . $queryParams . ($keyword ? '&' : '?') . 'page=' . ($currentPage - 1); ?>" 
                                   class="btn btn-secondary">
                                    <i class="icon-chevron-left"></i>
                                    上一页
                                </a>
                            <?php endif; ?>
                            
                            <span class="page-current">第 <?php echo $currentPage; ?> 页</span>
                            
                            <a href="<?php echo $baseUrl . $queryParams . ($keyword ? '&' : '?') . 'page=' . ($currentPage + 1); ?>" 
                               class="btn btn-secondary">
                                下一页
                                <i class="icon-chevron-right"></i>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
                
            <?php elseif (isset($goodsData)): ?>
                <!-- 错误状态 -->
                <div class="error-state">
                    <i class="icon-alert-circle"></i>
                    <h3>获取商品数据失败</h3>
                    <p><?php echo htmlspecialchars($goodsData['message']); ?></p>
                    <button onclick="location.reload()" class="btn btn-primary">
                        <i class="icon-refresh-cw"></i>
                        重试
                    </button>
                </div>
            <?php endif; ?>
        </main>
    </div>
    
    <!-- 商品详情模态框 -->
    <div class="modal" id="goodsDetailModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>商品详情</h3>
                <button onclick="closeModal('goodsDetailModal')" class="modal-close">
                    <i class="icon-x"></i>
                </button>
            </div>
            <div class="modal-body" id="goodsDetailContent">
                <div class="loading">加载中...</div>
            </div>
        </div>
    </div>
    
    <script src="<?php echo getAssetsBaseUrl(); ?>/js/admin.js"></script>
    <script>
        // 商品管理特定脚本
        function refreshGoods() {
            if (confirm('确定要刷新商品数据吗？这可能需要一些时间。')) {
                showLoading('正在刷新商品数据...');
                
                // 清理缓存并重新加载页面
                fetch('<?php echo getAdminBaseUrl(); ?>/api/cache/clear', {
                    method: 'POST'
                })
                .then(() => {
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                })
                .catch(error => {
                    hideLoading();
                    showMessage('刷新失败: ' + error.message, 'error');
                });
            }
        }
        
        function viewGoodsDetail(goodsId) {
            showModal('goodsDetailModal');
            
            const content = document.getElementById('goodsDetailContent');
            content.innerHTML = '<div class="loading">加载中...</div>';
            
            // 这里可以通过AJAX获取商品详情
            fetch(`/dataoke-service/api/goods?action=detail&id=${goodsId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.code === 0 && data.data) {
                        const goods = data.data;
                        content.innerHTML = `
                            <div class="goods-detail">
                                <div class="detail-image">
                                    <img src="${goods.pict_url || ''}" alt="${goods.title || ''}">
                                </div>
                                <div class="detail-info">
                                    <h4>${goods.title || ''}</h4>
                                    <div class="detail-price">
                                        <span class="current">¥${(goods.actual_price || 0).toFixed(2)}</span>
                                        ${goods.original_price ? `<span class="original">¥${goods.original_price.toFixed(2)}</span>` : ''}
                                    </div>
                                    <div class="detail-stats">
                                        <div class="stat-item">
                                            <label>月销量:</label>
                                            <span>${(goods.month_sales || 0).toLocaleString()}</span>
                                        </div>
                                        <div class="stat-item">
                                            <label>佣金比例:</label>
                                            <span>${(goods.commission_rate || 0).toFixed(2)}%</span>
                                        </div>
                                        <div class="stat-item">
                                            <label>优惠券:</label>
                                            <span>${goods.coupon_amount ? goods.coupon_amount + '元' : '无'}</span>
                                        </div>
                                    </div>
                                    <div class="detail-actions">
                                        <button onclick="copyGoodsLink('${goodsId}')" class="btn btn-primary">
                                            <i class="icon-copy"></i>
                                            复制推广链接
                                        </button>
                                    </div>
                                </div>
                            </div>
                        `;
                    } else {
                        content.innerHTML = `
                            <div class="error-message">
                                <i class="icon-alert-circle"></i>
                                <p>获取商品详情失败</p>
                            </div>
                        `;
                    }
                })
                .catch(error => {
                    content.innerHTML = `
                        <div class="error-message">
                            <i class="icon-alert-circle"></i>
                            <p>加载失败: ${error.message}</p>
                        </div>
                    `;
                });
        }
        
        function copyGoodsLink(goodsId) {
            // 这里可以生成推广链接并复制到剪贴板
            const link = `https://s.click.taobao.com/goods/${goodsId}`;
            
            if (navigator.clipboard) {
                navigator.clipboard.writeText(link).then(() => {
                    showMessage('链接已复制到剪贴板', 'success');
                }).catch(() => {
                    showMessage('复制失败，请手动复制', 'error');
                });
            } else {
                // 降级方案
                const textArea = document.createElement('textarea');
                textArea.value = link;
                document.body.appendChild(textArea);
                textArea.select();
                try {
                    document.execCommand('copy');
                    showMessage('链接已复制到剪贴板', 'success');
                } catch (err) {
                    showMessage('复制失败，请手动复制', 'error');
                }
                document.body.removeChild(textArea);
            }
        }
    </script>
</body>
</html>
