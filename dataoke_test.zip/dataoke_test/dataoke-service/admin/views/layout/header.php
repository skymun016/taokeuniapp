<?php
$auth = AdminAuth::getInstance();
$user = $auth->getCurrentUser();
?>
<header class="admin-header">
    <div class="header-left">
        <button class="sidebar-toggle" onclick="toggleSidebar()">
            <i class="icon-menu"></i>
        </button>
        <h1 class="header-title"><?php echo ADMIN_CONFIG['title']; ?></h1>
    </div>
    
    <div class="header-right">
        <div class="header-actions">
            <!-- 通知按钮 -->
            <button class="header-btn" onclick="showNotifications()">
                <i class="icon-bell"></i>
                <span class="badge">0</span>
            </button>
            
            <!-- 刷新按钮 -->
            <button class="header-btn" onclick="location.reload()">
                <i class="icon-refresh-cw"></i>
            </button>
            
            <!-- 用户菜单 -->
            <div class="user-menu">
                <button class="user-btn" onclick="toggleUserMenu()">
                    <div class="user-avatar">
                        <i class="icon-user"></i>
                    </div>
                    <span class="user-name"><?php echo htmlspecialchars($user['username']); ?></span>
                    <i class="icon-chevron-down"></i>
                </button>
                
                <div class="user-dropdown" id="userDropdown">
                    <div class="user-info">
                        <div class="user-avatar large">
                            <i class="icon-user"></i>
                        </div>
                        <div class="user-details">
                            <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                            <small><?php echo htmlspecialchars($user['role']); ?></small>
                        </div>
                    </div>
                    
                    <div class="dropdown-divider"></div>
                    
                    <a href="<?php echo getAdminBaseUrl(); ?>/settings" class="dropdown-item">
                        <i class="icon-settings"></i>
                        个人设置
                    </a>

                    <a href="<?php echo getAdminBaseUrl(); ?>/logs" class="dropdown-item">
                        <i class="icon-activity"></i>
                        活动日志
                    </a>

                    <div class="dropdown-divider"></div>

                    <a href="<?php echo getAdminBaseUrl(); ?>/logout" class="dropdown-item text-danger">
                        <i class="icon-log-out"></i>
                        退出登录
                    </a>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- 通知面板 -->
<div class="notification-panel" id="notificationPanel">
    <div class="notification-header">
        <h3>通知</h3>
        <button onclick="hideNotifications()">
            <i class="icon-x"></i>
        </button>
    </div>
    <div class="notification-content">
        <div class="notification-item">
            <div class="notification-icon info">
                <i class="icon-info"></i>
            </div>
            <div class="notification-text">
                <p>系统运行正常</p>
                <small>刚刚</small>
            </div>
        </div>
    </div>
</div>

<script>
// 头部相关脚本
function toggleSidebar() {
    document.body.classList.toggle('sidebar-collapsed');
}

function toggleUserMenu() {
    const dropdown = document.getElementById('userDropdown');
    dropdown.classList.toggle('show');
}

function showNotifications() {
    const panel = document.getElementById('notificationPanel');
    panel.classList.add('show');
}

function hideNotifications() {
    const panel = document.getElementById('notificationPanel');
    panel.classList.remove('show');
}

// 点击外部关闭下拉菜单
document.addEventListener('click', function(e) {
    if (!e.target.closest('.user-menu')) {
        document.getElementById('userDropdown').classList.remove('show');
    }
    
    if (!e.target.closest('.notification-panel') && !e.target.closest('.header-btn')) {
        hideNotifications();
    }
});
</script>
