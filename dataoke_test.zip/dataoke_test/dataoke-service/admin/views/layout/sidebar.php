<?php
$auth = AdminAuth::getInstance();
$currentPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
?>
<aside class="admin-sidebar">
    <div class="sidebar-content">
        <nav class="sidebar-nav">
            <?php foreach (ADMIN_MENU as $menuItem): ?>
                <?php if ($auth->hasPermission($menuItem['permission'])): ?>
                    <?php 
                    $isActive = strpos($currentPath, $menuItem['url']) === 0;
                    $activeClass = $isActive ? 'active' : '';
                    ?>
                    <a href="<?php echo $menuItem['url']; ?>" class="nav-item <?php echo $activeClass; ?>">
                        <i class="icon-<?php echo $menuItem['icon']; ?>"></i>
                        <span class="nav-text"><?php echo $menuItem['title']; ?></span>
                    </a>
                <?php endif; ?>
            <?php endforeach; ?>
        </nav>
        
        <div class="sidebar-footer">
            <div class="system-status">
                <div class="status-indicator" id="systemStatus">
                    <div class="status-dot success"></div>
                    <span>系统正常</span>
                </div>
            </div>
            
            <div class="version-info">
                <small>版本 <?php echo ADMIN_CONFIG['version']; ?></small>
            </div>
        </div>
    </div>
</aside>

<script>
// 侧边栏相关脚本
document.addEventListener('DOMContentLoaded', function() {
    // 检查系统状态
    checkSystemStatus();
    
    // 定时检查系统状态
    setInterval(checkSystemStatus, 60000); // 每分钟检查一次
});

function checkSystemStatus() {
    fetch('<?php echo getAdminBaseUrl(); ?>/api/status')
        .then(response => response.json())
        .then(data => {
            const statusElement = document.getElementById('systemStatus');
            const statusDot = statusElement.querySelector('.status-dot');
            const statusText = statusElement.querySelector('span');
            
            if (data.dataoke_status) {
                statusDot.className = 'status-dot success';
                statusText.textContent = '系统正常';
            } else {
                statusDot.className = 'status-dot error';
                statusText.textContent = '系统异常';
            }
        })
        .catch(error => {
            console.error('检查系统状态失败:', error);
            const statusElement = document.getElementById('systemStatus');
            const statusDot = statusElement.querySelector('.status-dot');
            const statusText = statusElement.querySelector('span');
            
            statusDot.className = 'status-dot warning';
            statusText.textContent = '状态未知';
        });
}
</script>
