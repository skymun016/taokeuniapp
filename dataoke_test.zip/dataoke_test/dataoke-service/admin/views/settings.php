<?php
$auth = AdminAuth::getInstance();
$user = $auth->getCurrentUser();
$canEdit = $auth->hasPermission('settings_edit');
$canManageUsers = $auth->hasPermission('user_manage');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系统设置 - <?php echo ADMIN_CONFIG['title']; ?></title>
    <link rel="stylesheet" href="<?php echo getAssetsBaseUrl(); ?>/css/admin.css">
</head>
<body>
    <?php include __DIR__ . '/layout/header.php'; ?>
    
    <div class="admin-container">
        <?php include __DIR__ . '/layout/sidebar.php'; ?>
        
        <main class="admin-main">
            <div class="page-header">
                <h1>系统设置</h1>
                <p>管理系统参数和用户账户</p>
            </div>
            
            <!-- 系统信息 -->
            <div class="settings-section">
                <div class="section-header">
                    <h2>系统信息</h2>
                </div>
                
                <div class="info-grid">
                    <div class="info-card">
                        <div class="info-icon">
                            <i class="icon-server"></i>
                        </div>
                        <div class="info-content">
                            <h3>服务端版本</h3>
                            <p><?php echo ADMIN_CONFIG['version']; ?></p>
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-icon">
                            <i class="icon-code"></i>
                        </div>
                        <div class="info-content">
                            <h3>PHP版本</h3>
                            <p><?php echo PHP_VERSION; ?></p>
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-icon">
                            <i class="icon-database"></i>
                        </div>
                        <div class="info-content">
                            <h3>数据存储</h3>
                            <p>JSON文件</p>
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-icon">
                            <i class="icon-shield"></i>
                        </div>
                        <div class="info-content">
                            <h3>安全状态</h3>
                            <p>正常</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- 个人设置 -->
            <div class="settings-section">
                <div class="section-header">
                    <h2>个人设置</h2>
                </div>
                
                <form class="settings-form" onsubmit="updateProfile(event)">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="current_username">当前用户名</label>
                            <input type="text" id="current_username" 
                                   value="<?php echo htmlspecialchars($user['username']); ?>" readonly>
                        </div>
                        
                        <div class="form-group">
                            <label for="current_role">用户角色</label>
                            <input type="text" id="current_role" 
                                   value="<?php echo htmlspecialchars($user['role']); ?>" readonly>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="current_password">当前密码</label>
                            <input type="password" id="current_password" name="current_password" 
                                   placeholder="输入当前密码以验证身份">
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password">新密码</label>
                            <input type="password" id="new_password" name="new_password" 
                                   placeholder="留空则不修改密码">
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="icon-save"></i>
                            更新个人信息
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- 系统参数 -->
            <?php if ($canEdit): ?>
                <div class="settings-section">
                    <div class="section-header">
                        <h2>系统参数</h2>
                    </div>
                    
                    <form class="settings-form" onsubmit="updateSystemSettings(event)">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="session_timeout">Session超时时间（秒）</label>
                                <input type="number" id="session_timeout" name="session_timeout" 
                                       value="<?php echo ADMIN_CONFIG['session_timeout']; ?>" min="300" max="86400">
                            </div>
                            
                            <div class="form-group">
                                <label for="max_login_attempts">最大登录尝试次数</label>
                                <input type="number" id="max_login_attempts" name="max_login_attempts" 
                                       value="<?php echo ADMIN_CONFIG['max_login_attempts']; ?>" min="3" max="20">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="lockout_time">账户锁定时间（秒）</label>
                                <input type="number" id="lockout_time" name="lockout_time" 
                                       value="<?php echo ADMIN_CONFIG['lockout_time']; ?>" min="300" max="3600">
                            </div>
                            
                            <div class="form-group">
                                <label for="logs_retention_days">日志保留天数</label>
                                <input type="number" id="logs_retention_days" name="logs_retention_days" 
                                       value="<?php echo ADMIN_CONFIG['logs_retention_days']; ?>" min="7" max="365">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="checkbox-label">
                                <input type="checkbox" name="enable_logs" 
                                       <?php echo ADMIN_CONFIG['enable_logs'] ? 'checked' : ''; ?>>
                                <span class="checkmark"></span>
                                启用操作日志记录
                            </label>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="icon-save"></i>
                                保存系统设置
                            </button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
            
            <!-- 用户管理 -->
            <?php if ($canManageUsers): ?>
                <div class="settings-section">
                    <div class="section-header">
                        <h2>用户管理</h2>
                        <div class="section-actions">
                            <button onclick="showAddUserModal()" class="btn btn-primary">
                                <i class="icon-user-plus"></i>
                                添加用户
                            </button>
                        </div>
                    </div>
                    
                    <div class="users-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>用户名</th>
                                    <th>角色</th>
                                    <th>状态</th>
                                    <th>最后登录</th>
                                    <th>登录次数</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody id="usersTableBody">
                                <tr>
                                    <td colspan="6" class="loading">加载中...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- 系统维护 -->
            <div class="settings-section">
                <div class="section-header">
                    <h2>系统维护</h2>
                </div>
                
                <div class="maintenance-actions">
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="icon-trash-2"></i>
                        </div>
                        <div class="action-content">
                            <h3>清理缓存</h3>
                            <p>清理所有API缓存文件</p>
                            <button onclick="clearAllCache()" class="btn btn-warning">
                                <i class="icon-trash-2"></i>
                                清理缓存
                            </button>
                        </div>
                    </div>
                    
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="icon-file-text"></i>
                        </div>
                        <div class="action-content">
                            <h3>清理日志</h3>
                            <p>清理过期的操作日志</p>
                            <button onclick="cleanOldLogs()" class="btn btn-warning">
                                <i class="icon-file-text"></i>
                                清理日志
                            </button>
                        </div>
                    </div>
                    
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="icon-download"></i>
                        </div>
                        <div class="action-content">
                            <h3>备份数据</h3>
                            <p>备份配置和用户数据</p>
                            <button onclick="backupData()" class="btn btn-info">
                                <i class="icon-download"></i>
                                备份数据
                            </button>
                        </div>
                    </div>
                    
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="icon-refresh-cw"></i>
                        </div>
                        <div class="action-content">
                            <h3>重启服务</h3>
                            <p>重新加载配置文件</p>
                            <button onclick="restartService()" class="btn btn-secondary">
                                <i class="icon-refresh-cw"></i>
                                重启服务
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <!-- 添加用户模态框 -->
    <?php if ($canManageUsers): ?>
        <div class="modal" id="addUserModal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>添加用户</h3>
                    <button onclick="closeModal('addUserModal')" class="modal-close">
                        <i class="icon-x"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form onsubmit="addUser(event)">
                        <div class="form-group">
                            <label for="new_username">用户名</label>
                            <input type="text" id="new_username" name="username" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="new_user_password">密码</label>
                            <input type="password" id="new_user_password" name="password" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="new_user_role">角色</label>
                            <select id="new_user_role" name="role" required>
                                <option value="viewer">查看者</option>
                                <option value="admin">管理员</option>
                                <option value="super_admin">超级管理员</option>
                            </select>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="icon-user-plus"></i>
                                添加用户
                            </button>
                            <button type="button" onclick="closeModal('addUserModal')" class="btn btn-secondary">
                                取消
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
    <script src="<?php echo getAssetsBaseUrl(); ?>/js/admin.js"></script>
    <script>
        // 系统设置特定脚本
        document.addEventListener('DOMContentLoaded', function() {
            <?php if ($canManageUsers): ?>
                loadUsers();
            <?php endif; ?>
        });
        
        function updateProfile(event) {
            event.preventDefault();
            showMessage('个人信息更新功能开发中...', 'info');
        }
        
        function updateSystemSettings(event) {
            event.preventDefault();
            showMessage('系统设置更新功能开发中...', 'info');
        }
        
        function clearAllCache() {
            if (confirm('确定要清理所有缓存吗？')) {
                showLoading('正在清理缓存...');
                
                fetch('<?php echo getAdminBaseUrl(); ?>/api/cache/clear', {
                    method: 'POST'
                })
                .then(response => response.json())
                .then(data => {
                    hideLoading();
                    if (data.success) {
                        showMessage(data.message, 'success');
                    } else {
                        showMessage(data.message, 'error');
                    }
                })
                .catch(error => {
                    hideLoading();
                    showMessage('清理失败: ' + error.message, 'error');
                });
            }
        }
        
        function cleanOldLogs() {
            if (confirm('确定要清理过期日志吗？')) {
                showMessage('日志清理功能开发中...', 'info');
            }
        }
        
        function backupData() {
            showMessage('数据备份功能开发中...', 'info');
        }
        
        function restartService() {
            if (confirm('确定要重启服务吗？这可能会中断当前连接。')) {
                showMessage('服务重启功能开发中...', 'info');
            }
        }
        
        <?php if ($canManageUsers): ?>
        function loadUsers() {
            // 模拟用户数据
            const users = [
                {
                    id: 1,
                    username: '<?php echo htmlspecialchars($user['username']); ?>',
                    role: '<?php echo htmlspecialchars($user['role']); ?>',
                    status: 'active',
                    last_login: '<?php echo $user['last_login'] ?? '从未登录'; ?>',
                    login_count: <?php echo $user['login_count'] ?? 0; ?>
                }
            ];
            
            const tbody = document.getElementById('usersTableBody');
            tbody.innerHTML = users.map(user => `
                <tr>
                    <td>${user.username}</td>
                    <td><span class="role-badge role-${user.role}">${user.role}</span></td>
                    <td><span class="status-badge status-${user.status}">${user.status}</span></td>
                    <td>${user.last_login}</td>
                    <td>${user.login_count}</td>
                    <td>
                        <button onclick="editUser(${user.id})" class="btn btn-sm btn-info">
                            <i class="icon-edit"></i>
                        </button>
                        ${user.id !== 1 ? `
                            <button onclick="deleteUser(${user.id})" class="btn btn-sm btn-danger">
                                <i class="icon-trash-2"></i>
                            </button>
                        ` : ''}
                    </td>
                </tr>
            `).join('');
        }
        
        function showAddUserModal() {
            showModal('addUserModal');
        }
        
        function addUser(event) {
            event.preventDefault();
            showMessage('添加用户功能开发中...', 'info');
            closeModal('addUserModal');
        }
        
        function editUser(userId) {
            showMessage('编辑用户功能开发中...', 'info');
        }
        
        function deleteUser(userId) {
            if (confirm('确定要删除此用户吗？')) {
                showMessage('删除用户功能开发中...', 'info');
            }
        }
        <?php endif; ?>
    </script>
</body>
</html>
