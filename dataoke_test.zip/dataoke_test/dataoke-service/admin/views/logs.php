<?php
$auth = AdminAuth::getInstance();
$canManage = $auth->hasPermission('logs_manage');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>日志管理 - <?php echo ADMIN_CONFIG['title']; ?></title>
    <link rel="stylesheet" href="<?php echo getAssetsBaseUrl(); ?>/css/admin.css">
</head>
<body>
    <?php include __DIR__ . '/layout/header.php'; ?>
    
    <div class="admin-container">
        <?php include __DIR__ . '/layout/sidebar.php'; ?>
        
        <main class="admin-main">
            <div class="page-header">
                <h1>日志管理</h1>
                <p>查看系统操作日志和API访问记录</p>
            </div>
            
            <?php if (isset($message)): ?>
                <div class="alert alert-success">
                    <i class="icon-check-circle"></i>
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>
            
            <!-- 日志统计 -->
            <div class="stats-section">
                <h2>日志统计 (最近7天)</h2>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="icon-file-text"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo number_format($logStats['total_logs']); ?></h3>
                            <p>总日志数</p>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="icon-users"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo count($logStats['user_stats']); ?></h3>
                            <p>活跃用户</p>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="icon-activity"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo count($logStats['action_stats']); ?></h3>
                            <p>操作类型</p>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="icon-calendar"></i>
                        </div>
                        <div class="stat-content">
                            <h3><?php echo count($logStats['daily_stats']); ?></h3>
                            <p>活跃天数</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- 过滤和搜索 -->
            <div class="filter-section">
                <form method="GET" class="filter-form">
                    <div class="filter-row">
                        <div class="filter-group">
                            <label for="username">用户名</label>
                            <input type="text" id="username" name="username" 
                                   value="<?php echo htmlspecialchars($_GET['username'] ?? ''); ?>"
                                   placeholder="搜索用户名">
                        </div>
                        
                        <div class="filter-group">
                            <label for="action">操作类型</label>
                            <select id="action" name="action">
                                <option value="">全部操作</option>
                                <?php foreach ($logStats['action_stats'] as $action => $count): ?>
                                    <option value="<?php echo htmlspecialchars($action); ?>"
                                            <?php echo ($_GET['action'] ?? '') === $action ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($action); ?> (<?php echo $count; ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <label for="date_from">开始日期</label>
                            <input type="date" id="date_from" name="date_from" 
                                   value="<?php echo htmlspecialchars($_GET['date_from'] ?? ''); ?>">
                        </div>
                        
                        <div class="filter-group">
                            <label for="date_to">结束日期</label>
                            <input type="date" id="date_to" name="date_to" 
                                   value="<?php echo htmlspecialchars($_GET['date_to'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <div class="filter-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="icon-search"></i>
                            筛选
                        </button>
                        <a href="<?php echo getAdminBaseUrl(); ?>/logs" class="btn btn-secondary">
                            <i class="icon-refresh-cw"></i>
                            重置
                        </a>
                        <?php if ($canManage): ?>
                            <button type="button" onclick="cleanOldLogs()" class="btn btn-warning">
                                <i class="icon-trash-2"></i>
                                清理过期日志
                            </button>
                        <?php endif; ?>
                        <button type="button" onclick="exportLogs()" class="btn btn-info">
                            <i class="icon-download"></i>
                            导出日志
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- 日志列表 -->
            <div class="logs-section">
                <div class="section-header">
                    <h2>操作日志</h2>
                    <div class="section-info">
                        <span>共 <?php echo number_format($logsData['total']); ?> 条记录</span>
                        <span>第 <?php echo $logsData['page']; ?>/<?php echo $logsData['totalPages']; ?> 页</span>
                    </div>
                </div>
                
                <div class="logs-table">
                    <table>
                        <thead>
                            <tr>
                                <th>时间</th>
                                <th>用户</th>
                                <th>操作</th>
                                <th>描述</th>
                                <th>IP地址</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($logsData['logs'])): ?>
                                <?php foreach ($logsData['logs'] as $log): ?>
                                    <tr>
                                        <td class="log-time">
                                            <?php echo date('m-d H:i:s', strtotime($log['timestamp'])); ?>
                                        </td>
                                        <td class="log-user">
                                            <?php echo htmlspecialchars($log['username']); ?>
                                        </td>
                                        <td class="log-action">
                                            <span class="action-badge action-<?php echo htmlspecialchars($log['action']); ?>">
                                                <?php echo htmlspecialchars($log['action']); ?>
                                            </span>
                                        </td>
                                        <td class="log-description">
                                            <?php echo htmlspecialchars($log['description']); ?>
                                        </td>
                                        <td class="log-ip">
                                            <?php echo htmlspecialchars($log['ip']); ?>
                                        </td>
                                        <td class="log-actions">
                                            <button onclick="viewLogDetail('<?php echo $log['id']; ?>')" 
                                                    class="btn btn-sm btn-info">
                                                <i class="icon-eye"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="empty-state">
                                        <i class="icon-file-text"></i>
                                        <p>暂无日志记录</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- 分页 -->
                <?php if ($logsData['totalPages'] > 1): ?>
                    <div class="pagination">
                        <?php 
                        $currentPage = $logsData['page'];
                        $totalPages = $logsData['totalPages'];
                        $queryParams = http_build_query(array_filter([
                            'username' => $_GET['username'] ?? '',
                            'action' => $_GET['action'] ?? '',
                            'date_from' => $_GET['date_from'] ?? '',
                            'date_to' => $_GET['date_to'] ?? ''
                        ]));
                        $baseUrl = getAdminBaseUrl() . '/logs';
                        ?>
                        
                        <?php if ($currentPage > 1): ?>
                            <a href="<?php echo $baseUrl . '?' . $queryParams . '&page=' . ($currentPage - 1); ?>" 
                               class="btn btn-secondary">
                                <i class="icon-chevron-left"></i>
                                上一页
                            </a>
                        <?php endif; ?>
                        
                        <span class="page-info">
                            第 <?php echo $currentPage; ?> / <?php echo $totalPages; ?> 页
                        </span>
                        
                        <?php if ($currentPage < $totalPages): ?>
                            <a href="<?php echo $baseUrl . '?' . $queryParams . '&page=' . ($currentPage + 1); ?>" 
                               class="btn btn-secondary">
                                下一页
                                <i class="icon-chevron-right"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    
    <!-- 日志详情模态框 -->
    <div class="modal" id="logDetailModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>日志详情</h3>
                <button onclick="closeModal('logDetailModal')" class="modal-close">
                    <i class="icon-x"></i>
                </button>
            </div>
            <div class="modal-body" id="logDetailContent">
                <div class="loading">加载中...</div>
            </div>
        </div>
    </div>
    
    <script src="<?php echo getAssetsBaseUrl(); ?>/js/admin.js"></script>
    <script>
        // 日志管理特定脚本
        function cleanOldLogs() {
            if (confirm('确定要清理过期日志吗？此操作不可恢复。')) {
                showLoading('正在清理过期日志...');
                
                const form = new FormData();
                form.append('action', 'clean_old');
                
                fetch('<?php echo getAdminBaseUrl(); ?>/logs', {
                    method: 'POST',
                    body: form
                })
                .then(response => response.text())
                .then(html => {
                    hideLoading();
                    
                    // 解析响应中的消息
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    const successAlert = doc.querySelector('.alert-success');
                    
                    if (successAlert) {
                        showMessage(successAlert.textContent.trim(), 'success');
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        showMessage('清理完成', 'success');
                        setTimeout(() => location.reload(), 1000);
                    }
                })
                .catch(error => {
                    hideLoading();
                    showMessage('清理失败: ' + error.message, 'error');
                });
            }
        }
        
        function exportLogs() {
            const params = new URLSearchParams(window.location.search);
            params.set('export', 'json');
            
            const exportUrl = '<?php echo getAdminBaseUrl(); ?>/logs?' + params.toString();
            
            showLoading('正在导出日志...');
            
            fetch(exportUrl)
                .then(response => response.blob())
                .then(blob => {
                    hideLoading();
                    
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'logs_' + new Date().toISOString().slice(0, 10) + '.json';
                    document.body.appendChild(a);
                    a.click();
                    window.URL.revokeObjectURL(url);
                    document.body.removeChild(a);
                    
                    showMessage('日志导出成功', 'success');
                })
                .catch(error => {
                    hideLoading();
                    showMessage('导出失败: ' + error.message, 'error');
                });
        }
        
        function viewLogDetail(logId) {
            showModal('logDetailModal');
            
            const content = document.getElementById('logDetailContent');
            content.innerHTML = '<div class="loading">加载中...</div>';
            
            // 从当前页面的日志数据中查找对应的日志
            const logs = <?php echo json_encode($logsData['logs']); ?>;
            const log = logs.find(l => l.id === logId);
            
            if (log) {
                content.innerHTML = `
                    <div class="log-detail">
                        <div class="detail-row">
                            <label>日志ID:</label>
                            <span>${log.id}</span>
                        </div>
                        <div class="detail-row">
                            <label>时间:</label>
                            <span>${log.timestamp}</span>
                        </div>
                        <div class="detail-row">
                            <label>用户:</label>
                            <span>${log.username} (ID: ${log.user_id})</span>
                        </div>
                        <div class="detail-row">
                            <label>操作:</label>
                            <span class="action-badge action-${log.action}">${log.action}</span>
                        </div>
                        <div class="detail-row">
                            <label>描述:</label>
                            <span>${log.description}</span>
                        </div>
                        <div class="detail-row">
                            <label>IP地址:</label>
                            <span>${log.ip}</span>
                        </div>
                        <div class="detail-row">
                            <label>用户代理:</label>
                            <span class="user-agent">${log.user_agent}</span>
                        </div>
                        ${log.data && Object.keys(log.data).length > 0 ? `
                            <div class="detail-row">
                                <label>详细数据:</label>
                                <pre class="log-data">${JSON.stringify(log.data, null, 2)}</pre>
                            </div>
                        ` : ''}
                    </div>
                `;
            } else {
                content.innerHTML = `
                    <div class="error-message">
                        <i class="icon-alert-circle"></i>
                        <p>未找到日志详情</p>
                    </div>
                `;
            }
        }
    </script>
</body>
</html>
