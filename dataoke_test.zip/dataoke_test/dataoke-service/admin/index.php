<?php
/**
 * 管理后台入口文件和路由
 */

// 引入配置文件
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/admin_config.php';

// 引入公共函数
require_once __DIR__ . '/../lib/common.php';

// 引入管理后台类库
require_once __DIR__ . '/lib/AdminAuth.php';
require_once __DIR__ . '/lib/AdminLogger.php';
require_once __DIR__ . '/lib/AdminConfig.php';

// 引入大淘客适配器
require_once __DIR__ . '/../lib/DataokeAdapter.php';

// 获取请求路径
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// 动态获取基础路径
$scriptName = $_SERVER['SCRIPT_NAME'];
$basePath = dirname($scriptName);

// 移除基础路径
if (strpos($path, $basePath) === 0) {
    $path = substr($path, strlen($basePath));
}

// 如果路径为空，重定向到仪表板
if (empty($path) || $path === '/') {
    $path = '/dashboard';
}

// 路由分发
switch ($path) {
    case '/login':
        handleLogin();
        break;
        
    case '/logout':
        handleLogout();
        break;
        
    case '/dashboard':
        requireAuth();
        showDashboard();
        break;
        
    case '/config':
        requireAuth();
        handleConfig();
        break;
        
    case '/goods':
        requireAuth();
        handleGoods();
        break;
        
    case '/logs':
        requireAuth();
        handleLogs();
        break;
        
    case '/settings':
        requireAuth();
        handleSettings();
        break;
        
    case '/api/status':
        requireAuth();
        handleApiStatus();
        break;
        
    case '/api/cache/clear':
        requireAuth();
        handleCacheClear();
        break;
        
    default:
        http_response_code(404);
        echo '页面不存在';
        break;
}

/**
 * 要求认证
 */
function requireAuth() {
    $auth = AdminAuth::getInstance();
    $auth->requireLogin();
}

/**
 * 处理登录
 */
function handleLogin() {
    $auth = AdminAuth::getInstance();
    
    // 如果已登录，重定向到仪表板
    if ($auth->isLoggedIn()) {
        header('Location: ' . getAdminBaseUrl() . '/dashboard');
        exit;
    }
    
    // 处理登录表单提交
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember']);
        
        $result = $auth->login($username, $password, $remember);
        
        if ($result['success']) {
            header('Location: ' . getAdminBaseUrl() . '/dashboard');
            exit;
        } else {
            $error = $result['message'];
        }
    }
    
    // 显示登录页面
    include __DIR__ . '/views/login.php';
}

/**
 * 处理登出
 */
function handleLogout() {
    $auth = AdminAuth::getInstance();
    $auth->logout();
    header('Location: ' . getAdminBaseUrl() . '/login');
    exit;
}

/**
 * 显示仪表板
 */
function showDashboard() {
    $auth = AdminAuth::getInstance();
    $auth->requirePermission('dashboard');
    
    // 获取系统状态信息
    $statusData = getSystemStatus();
    
    include __DIR__ . '/views/dashboard.php';
}

/**
 * 处理配置管理
 */
function handleConfig() {
    $auth = AdminAuth::getInstance();
    $auth->requirePermission('config_view');
    
    $adminConfig = AdminConfig::getInstance();
    $message = '';
    $error = '';
    
    // 处理配置更新
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!$auth->hasPermission('config_edit')) {
            $error = '权限不足';
        } else {
            $action = $_POST['action'] ?? '';
            
            switch ($action) {
                case 'update_dataoke':
                    $result = $adminConfig->updateDataokeConfig($_POST);
                    if ($result['success']) {
                        $message = $result['message'];
                    } else {
                        $error = $result['message'];
                    }
                    break;
                    
                case 'update_cache':
                    $result = $adminConfig->updateCacheConfig($_POST);
                    if ($result['success']) {
                        $message = $result['message'];
                    } else {
                        $error = $result['message'];
                    }
                    break;
                    
                case 'update_cors':
                    $result = $adminConfig->updateCorsConfig($_POST);
                    if ($result['success']) {
                        $message = $result['message'];
                    } else {
                        $error = $result['message'];
                    }
                    break;
                    
                case 'test_dataoke':
                    $result = $adminConfig->testDataokeConfig();
                    if ($result['success']) {
                        $message = '大淘客连接测试成功';
                    } else {
                        $error = '大淘客连接测试失败: ' . $result['message'];
                    }
                    break;
            }
        }
    }
    
    // 获取当前配置
    $dataokeConfig = $adminConfig->getDataokeConfig();
    $cacheConfig = $adminConfig->getCacheConfig();
    $corsConfig = $adminConfig->getCorsConfig();
    
    include __DIR__ . '/views/config.php';
}

/**
 * 处理商品管理
 */
function handleGoods() {
    $auth = AdminAuth::getInstance();
    $auth->requirePermission('goods_view');
    
    // 获取商品数据
    $page = intval($_GET['page'] ?? 1);
    $keyword = $_GET['keyword'] ?? '';
    
    $goodsData = getGoodsData($page, $keyword);
    
    include __DIR__ . '/views/goods.php';
}

/**
 * 处理日志管理
 */
function handleLogs() {
    $auth = AdminAuth::getInstance();
    $auth->requirePermission('logs_view');
    
    $logger = AdminLogger::getInstance();
    
    // 处理日志操作
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'clean_old' && $auth->hasPermission('logs_manage')) {
            $removedCount = $logger->cleanOldLogs();
            $message = "已清理 {$removedCount} 条过期日志";
        }
    }
    
    // 获取日志数据
    $page = intval($_GET['page'] ?? 1);
    $filters = [
        'username' => $_GET['username'] ?? '',
        'action' => $_GET['action'] ?? '',
        'date_from' => $_GET['date_from'] ?? '',
        'date_to' => $_GET['date_to'] ?? ''
    ];
    
    $logsData = $logger->getLogs($page, 50, $filters);
    $logStats = $logger->getLogStats();
    
    include __DIR__ . '/views/logs.php';
}

/**
 * 处理系统设置
 */
function handleSettings() {
    $auth = AdminAuth::getInstance();
    $auth->requirePermission('settings_view');
    
    include __DIR__ . '/views/settings.php';
}

/**
 * 处理API状态查询
 */
function handleApiStatus() {
    header('Content-Type: application/json');
    
    $status = getSystemStatus();
    echo json_encode($status);
}

/**
 * 处理缓存清理
 */
function handleCacheClear() {
    $auth = AdminAuth::getInstance();
    $auth->requirePermission('goods_manage');
    
    header('Content-Type: application/json');
    
    try {
        $cachePath = CACHE_CONFIG['path'];
        $files = glob($cachePath . '*.cache');
        $cleared = 0;
        
        foreach ($files as $file) {
            if (unlink($file)) {
                $cleared++;
            }
        }
        
        AdminLogger::getInstance()->log('cache_clear', "清理缓存文件 {$cleared} 个");
        
        echo json_encode([
            'success' => true,
            'message' => "已清理 {$cleared} 个缓存文件"
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => '清理缓存失败: ' . $e->getMessage()
        ]);
    }
}

/**
 * 获取系统状态
 */
function getSystemStatus() {
    $adapter = getDataokeAdapter();
    $dataokeStatus = $adapter->testConnection();
    
    // 缓存状态
    $cachePath = CACHE_CONFIG['path'];
    $cacheFiles = glob($cachePath . '*.cache');
    $cacheSize = 0;
    foreach ($cacheFiles as $file) {
        $cacheSize += filesize($file);
    }
    
    // 日志状态
    $logFiles = glob(__DIR__ . '/../logs/*.log');
    $logSize = 0;
    foreach ($logFiles as $file) {
        $logSize += filesize($file);
    }
    
    return [
        'dataoke_status' => $dataokeStatus['success'],
        'dataoke_message' => $dataokeStatus['message'],
        'cache_files' => count($cacheFiles),
        'cache_size' => formatBytes($cacheSize),
        'log_files' => count($logFiles),
        'log_size' => formatBytes($logSize),
        'server_time' => date('Y-m-d H:i:s'),
        'php_version' => PHP_VERSION,
        'memory_usage' => formatBytes(memory_get_usage(true)),
        'disk_free' => formatBytes(disk_free_space(__DIR__))
    ];
}

/**
 * 获取商品数据
 */
function getGoodsData($page = 1, $keyword = '') {
    try {
        $adapter = getDataokeAdapter();
        
        $params = [
            'pageId' => $page,
            'pageSize' => 20
        ];
        
        if (!empty($keyword)) {
            $result = $adapter->searchGoods($keyword, $params);
        } else {
            $result = $adapter->getGoodsList($params);
        }
        
        if ($result['success']) {
            return [
                'success' => true,
                'data' => $result['data'],
                'page' => $page,
                'keyword' => $keyword
            ];
        } else {
            return [
                'success' => false,
                'message' => $result['message']
            ];
        }
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => '获取商品数据失败: ' . $e->getMessage()
        ];
    }
}

/**
 * 格式化字节数
 */
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, $precision) . ' ' . $units[$i];
}
?>
