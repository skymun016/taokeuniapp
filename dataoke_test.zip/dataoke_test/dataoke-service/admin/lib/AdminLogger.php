<?php
/**
 * 管理后台日志记录类
 */

class AdminLogger
{
    private static $instance = null;
    
    /**
     * 获取单例实例
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 记录操作日志
     */
    public function log($action, $description, $data = [])
    {
        if (!ADMIN_CONFIG['enable_logs']) {
            return;
        }
        
        $auth = AdminAuth::getInstance();
        $user = $auth->getCurrentUser();
        
        $logEntry = [
            'id' => $this->generateLogId(),
            'timestamp' => date('Y-m-d H:i:s'),
            'user_id' => $user['id'] ?? 0,
            'username' => $user['username'] ?? 'system',
            'action' => $action,
            'description' => $description,
            'data' => $data,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ];
        
        $this->writeLog($logEntry);
    }
    
    /**
     * 获取日志列表
     */
    public function getLogs($page = 1, $pageSize = 50, $filters = [])
    {
        $logs = $this->readLogs();
        
        // 应用过滤器
        if (!empty($filters)) {
            $logs = array_filter($logs, function($log) use ($filters) {
                // 按用户过滤
                if (!empty($filters['username']) && 
                    stripos($log['username'], $filters['username']) === false) {
                    return false;
                }
                
                // 按操作过滤
                if (!empty($filters['action']) && 
                    stripos($log['action'], $filters['action']) === false) {
                    return false;
                }
                
                // 按日期范围过滤
                if (!empty($filters['date_from']) && 
                    $log['timestamp'] < $filters['date_from']) {
                    return false;
                }
                
                if (!empty($filters['date_to']) && 
                    $log['timestamp'] > $filters['date_to']) {
                    return false;
                }
                
                return true;
            });
        }
        
        // 按时间倒序排列
        usort($logs, function($a, $b) {
            return strtotime($b['timestamp']) - strtotime($a['timestamp']);
        });
        
        // 分页
        $total = count($logs);
        $offset = ($page - 1) * $pageSize;
        $logs = array_slice($logs, $offset, $pageSize);
        
        return [
            'logs' => $logs,
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize,
            'totalPages' => ceil($total / $pageSize)
        ];
    }
    
    /**
     * 清理过期日志
     */
    public function cleanOldLogs()
    {
        $logs = $this->readLogs();
        $retentionDays = ADMIN_CONFIG['logs_retention_days'];
        $cutoffTime = time() - ($retentionDays * 24 * 3600);
        
        $filteredLogs = array_filter($logs, function($log) use ($cutoffTime) {
            return strtotime($log['timestamp']) > $cutoffTime;
        });
        
        $removedCount = count($logs) - count($filteredLogs);
        
        if ($removedCount > 0) {
            $this->writeLogs($filteredLogs);
            $this->log('system', "清理过期日志 {$removedCount} 条");
        }
        
        return $removedCount;
    }
    
    /**
     * 获取日志统计信息
     */
    public function getLogStats($days = 7)
    {
        $logs = $this->readLogs();
        $cutoffTime = time() - ($days * 24 * 3600);
        
        // 过滤最近N天的日志
        $recentLogs = array_filter($logs, function($log) use ($cutoffTime) {
            return strtotime($log['timestamp']) > $cutoffTime;
        });
        
        // 统计各种操作
        $actionStats = [];
        $userStats = [];
        $dailyStats = [];
        
        foreach ($recentLogs as $log) {
            // 操作统计
            $action = $log['action'];
            $actionStats[$action] = ($actionStats[$action] ?? 0) + 1;
            
            // 用户统计
            $username = $log['username'];
            $userStats[$username] = ($userStats[$username] ?? 0) + 1;
            
            // 每日统计
            $date = date('Y-m-d', strtotime($log['timestamp']));
            $dailyStats[$date] = ($dailyStats[$date] ?? 0) + 1;
        }
        
        return [
            'total_logs' => count($recentLogs),
            'action_stats' => $actionStats,
            'user_stats' => $userStats,
            'daily_stats' => $dailyStats,
            'period_days' => $days
        ];
    }
    
    /**
     * 导出日志
     */
    public function exportLogs($format = 'json', $filters = [])
    {
        $result = $this->getLogs(1, 10000, $filters); // 获取所有匹配的日志
        $logs = $result['logs'];
        
        switch ($format) {
            case 'csv':
                return $this->exportToCsv($logs);
            case 'json':
            default:
                return json_encode($logs, JSON_PRETTY_PRINT);
        }
    }
    
    /**
     * 导出为CSV格式
     */
    private function exportToCsv($logs)
    {
        $output = "时间,用户,操作,描述,IP地址\n";
        
        foreach ($logs as $log) {
            $output .= sprintf(
                "%s,%s,%s,%s,%s\n",
                $log['timestamp'],
                $log['username'],
                $log['action'],
                str_replace(['"', ','], ['""', '，'], $log['description']),
                $log['ip']
            );
        }
        
        return $output;
    }
    
    /**
     * 生成日志ID
     */
    private function generateLogId()
    {
        return uniqid() . '_' . time();
    }
    
    /**
     * 写入日志
     */
    private function writeLog($logEntry)
    {
        $logs = $this->readLogs();
        $logs[] = $logEntry;
        
        // 限制内存中的日志数量
        if (count($logs) > 10000) {
            $logs = array_slice($logs, -5000); // 只保留最新的5000条
        }
        
        $this->writeLogs($logs);
    }
    
    /**
     * 读取所有日志
     */
    private function readLogs()
    {
        if (!file_exists(ADMIN_LOGS_FILE)) {
            return [];
        }
        
        $content = file_get_contents(ADMIN_LOGS_FILE);
        return json_decode($content, true) ?: [];
    }
    
    /**
     * 写入所有日志
     */
    private function writeLogs($logs)
    {
        file_put_contents(ADMIN_LOGS_FILE, json_encode($logs, JSON_PRETTY_PRINT));
    }
}
?>
