<?php
/**
 * 管理后台配置管理类
 */

// 引入数据库适配器
require_once __DIR__ . '/DatabaseAdapter.php';

class AdminConfig
{
    private static $instance = null;
    private $db = null;
    private $useDatabase = false;

    /**
     * 获取单例实例
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * 构造函数
     */
    private function __construct()
    {
        // 初始化数据库连接
        try {
            $this->db = DatabaseAdapter::getInstance();
            $this->useDatabase = $this->db->isAvailable();
        } catch (Exception $e) {
            error_log('Database initialization failed in AdminConfig: ' . $e->getMessage());
            $this->useDatabase = false;
        }
    }
    
    /**
     * 获取大淘客配置
     */
    public function getDataokeConfig()
    {
        if ($this->useDatabase) {
            try {
                $sql = "SELECT * FROM dtk_dataoke_config WHERE status = 'active' AND is_default = 1 LIMIT 1";
                $config = $this->db->fetchOne($sql);

                if ($config) {
                    return [
                        'app_key' => $config['app_key'],
                        'app_secret' => $config['app_secret'],
                        'pid' => $config['pid'],
                        'version' => $config['version']
                    ];
                }
            } catch (Exception $e) {
                error_log('Failed to get dataoke config from database: ' . $e->getMessage());
            }
        }

        // 回退到常量配置
        return DATAOKE_CONFIG;
    }

    /**
     * 获取所有大淘客配置
     */
    public function getAllDataokeConfigs()
    {
        if ($this->useDatabase) {
            try {
                $sql = "SELECT * FROM dtk_dataoke_config WHERE status = 'active' ORDER BY is_default DESC, created_time DESC";
                return $this->db->fetchAll($sql);
            } catch (Exception $e) {
                error_log('Failed to get all dataoke configs: ' . $e->getMessage());
            }
        }

        return [];
    }
    
    /**
     * 更新大淘客配置
     */
    public function updateDataokeConfig($config)
    {
        $configFile = __DIR__ . '/../../config/config.php';
        $content = file_get_contents($configFile);
        
        // 备份原配置
        $this->backupConfig();
        
        // 构建新的配置数组
        $newConfig = [
            'app_key' => $config['app_key'] ?? DATAOKE_CONFIG['app_key'],
            'app_secret' => $config['app_secret'] ?? DATAOKE_CONFIG['app_secret'],
            'pid' => $config['pid'] ?? DATAOKE_CONFIG['pid'],
            'version' => $config['version'] ?? DATAOKE_CONFIG['version']
        ];
        
        // 验证配置
        $validation = $this->validateDataokeConfig($newConfig);
        if (!$validation['valid']) {
            return [
                'success' => false,
                'message' => $validation['message']
            ];
        }
        
        // 替换配置内容
        $newConfigStr = var_export($newConfig, true);
        $pattern = '/define\(\'DATAOKE_CONFIG\',\s*\[.*?\]\);/s';
        $replacement = "define('DATAOKE_CONFIG', $newConfigStr);";
        $newContent = preg_replace($pattern, $replacement, $content);
        
        if ($newContent === null) {
            return [
                'success' => false,
                'message' => '配置文件格式错误'
            ];
        }
        
        // 写入文件
        if (file_put_contents($configFile, $newContent) === false) {
            return [
                'success' => false,
                'message' => '配置文件写入失败'
            ];
        }
        
        // 记录日志
        AdminLogger::getInstance()->log('config_update', '更新大淘客配置', [
            'old_config' => DATAOKE_CONFIG,
            'new_config' => $newConfig
        ]);
        
        return [
            'success' => true,
            'message' => '配置更新成功'
        ];
    }
    
    /**
     * 获取缓存配置
     */
    public function getCacheConfig()
    {
        return CACHE_CONFIG;
    }
    
    /**
     * 更新缓存配置
     */
    public function updateCacheConfig($config)
    {
        $configFile = __DIR__ . '/../../config/config.php';
        $content = file_get_contents($configFile);
        
        // 备份原配置
        $this->backupConfig();
        
        // 构建新的配置数组
        $newConfig = [
            'type' => $config['type'] ?? CACHE_CONFIG['type'],
            'path' => $config['path'] ?? CACHE_CONFIG['path'],
            'expire' => [
                'goods_list' => intval($config['expire']['goods_list'] ?? CACHE_CONFIG['expire']['goods_list']),
                'goods_detail' => intval($config['expire']['goods_detail'] ?? CACHE_CONFIG['expire']['goods_detail']),
                'category' => intval($config['expire']['category'] ?? CACHE_CONFIG['expire']['category']),
                'search' => intval($config['expire']['search'] ?? CACHE_CONFIG['expire']['search'])
            ]
        ];
        
        // 验证配置
        $validation = $this->validateCacheConfig($newConfig);
        if (!$validation['valid']) {
            return [
                'success' => false,
                'message' => $validation['message']
            ];
        }
        
        // 替换配置内容
        $newConfigStr = var_export($newConfig, true);
        $pattern = '/define\(\'CACHE_CONFIG\',\s*\[.*?\]\);/s';
        $replacement = "define('CACHE_CONFIG', $newConfigStr);";
        $newContent = preg_replace($pattern, $replacement, $content);
        
        if ($newContent === null) {
            return [
                'success' => false,
                'message' => '配置文件格式错误'
            ];
        }
        
        // 写入文件
        if (file_put_contents($configFile, $newContent) === false) {
            return [
                'success' => false,
                'message' => '配置文件写入失败'
            ];
        }
        
        // 记录日志
        AdminLogger::getInstance()->log('config_update', '更新缓存配置', [
            'old_config' => CACHE_CONFIG,
            'new_config' => $newConfig
        ]);
        
        return [
            'success' => true,
            'message' => '缓存配置更新成功'
        ];
    }
    
    /**
     * 获取CORS配置
     */
    public function getCorsConfig()
    {
        return CORS_CONFIG;
    }
    
    /**
     * 更新CORS配置
     */
    public function updateCorsConfig($config)
    {
        $configFile = __DIR__ . '/../../config/config.php';
        $content = file_get_contents($configFile);
        
        // 备份原配置
        $this->backupConfig();
        
        // 构建新的配置数组
        $newConfig = [
            'allow_origin' => $config['allow_origin'] ?? CORS_CONFIG['allow_origin'],
            'allow_methods' => $config['allow_methods'] ?? CORS_CONFIG['allow_methods'],
            'allow_headers' => $config['allow_headers'] ?? CORS_CONFIG['allow_headers'],
            'allow_credentials' => $config['allow_credentials'] ?? CORS_CONFIG['allow_credentials']
        ];
        
        // 替换配置内容
        $newConfigStr = var_export($newConfig, true);
        $pattern = '/define\(\'CORS_CONFIG\',\s*\[.*?\]\);/s';
        $replacement = "define('CORS_CONFIG', $newConfigStr);";
        $newContent = preg_replace($pattern, $replacement, $content);
        
        if ($newContent === null) {
            return [
                'success' => false,
                'message' => '配置文件格式错误'
            ];
        }
        
        // 写入文件
        if (file_put_contents($configFile, $newContent) === false) {
            return [
                'success' => false,
                'message' => '配置文件写入失败'
            ];
        }
        
        // 记录日志
        AdminLogger::getInstance()->log('config_update', '更新CORS配置', [
            'old_config' => CORS_CONFIG,
            'new_config' => $newConfig
        ]);
        
        return [
            'success' => true,
            'message' => 'CORS配置更新成功'
        ];
    }
    
    /**
     * 测试大淘客配置
     */
    public function testDataokeConfig($config = null)
    {
        if ($config === null) {
            $config = DATAOKE_CONFIG;
        }
        
        try {
            $adapter = new DataokeAdapter(
                $config['app_key'],
                $config['app_secret'],
                $config['pid'],
                $config['version']
            );
            
            $result = $adapter->testConnection();
            
            AdminLogger::getInstance()->log('config_test', '测试大淘客配置', [
                'config' => $config,
                'result' => $result
            ]);
            
            return $result;
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => '测试失败: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * 备份配置文件
     */
    private function backupConfig()
    {
        $configFile = __DIR__ . '/../../config/config.php';
        $backupFile = __DIR__ . '/../../config/config_backup_' . date('Y-m-d_H-i-s') . '.php';
        
        copy($configFile, $backupFile);
        
        // 只保留最近10个备份文件
        $backupFiles = glob(__DIR__ . '/../../config/config_backup_*.php');
        if (count($backupFiles) > 10) {
            usort($backupFiles, function($a, $b) {
                return filemtime($a) - filemtime($b);
            });
            
            $filesToDelete = array_slice($backupFiles, 0, count($backupFiles) - 10);
            foreach ($filesToDelete as $file) {
                unlink($file);
            }
        }
    }
    
    /**
     * 验证大淘客配置
     */
    private function validateDataokeConfig($config)
    {
        if (empty($config['app_key'])) {
            return ['valid' => false, 'message' => 'App Key不能为空'];
        }
        
        if (empty($config['app_secret'])) {
            return ['valid' => false, 'message' => 'App Secret不能为空'];
        }
        
        if (empty($config['pid'])) {
            return ['valid' => false, 'message' => 'PID不能为空'];
        }
        
        if (empty($config['version'])) {
            return ['valid' => false, 'message' => 'API版本不能为空'];
        }
        
        return ['valid' => true, 'message' => '配置验证通过'];
    }
    
    /**
     * 验证缓存配置
     */
    private function validateCacheConfig($config)
    {
        if (!in_array($config['type'], ['file', 'redis'])) {
            return ['valid' => false, 'message' => '缓存类型必须是file或redis'];
        }
        
        foreach ($config['expire'] as $key => $value) {
            if (!is_numeric($value) || $value < 0) {
                return ['valid' => false, 'message' => "缓存过期时间 {$key} 必须是非负数"];
            }
        }
        
        return ['valid' => true, 'message' => '缓存配置验证通过'];
    }
}
?>
