<?php
/**
 * 数据库适配器类
 * 处理管理后台的数据库操作
 */

class DatabaseAdapter
{
    private static $instance = null;
    private $pdo = null;
    private $config = null;
    
    /**
     * 获取单例实例
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 构造函数
     */
    private function __construct()
    {
        $this->loadDatabaseConfig();
        $this->connect();
    }
    
    /**
     * 加载数据库配置
     */
    private function loadDatabaseConfig()
    {
        // 从环境变量或配置文件加载数据库配置
        $this->config = [
            'host' => $_ENV['DB_HOST'] ?? 'localhost',
            'port' => $_ENV['DB_PORT'] ?? '3306',
            'database' => $_ENV['DB_NAME'] ?? 'dataoke_admin',
            'username' => $_ENV['DB_USER'] ?? 'root',
            'password' => $_ENV['DB_PASS'] ?? '',
            'charset' => 'utf8mb4'
        ];
        
        // 如果没有环境变量，尝试从配置文件读取
        $configFile = __DIR__ . '/../../config/database.php';
        if (file_exists($configFile)) {
            $dbConfig = include $configFile;
            $this->config = array_merge($this->config, $dbConfig);
        }
    }
    
    /**
     * 连接数据库
     */
    private function connect()
    {
        try {
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=%s',
                $this->config['host'],
                $this->config['port'],
                $this->config['database'],
                $this->config['charset']
            );
            
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES {$this->config['charset']}"
            ];
            
            $this->pdo = new PDO($dsn, $this->config['username'], $this->config['password'], $options);
        } catch (PDOException $e) {
            // 如果数据库连接失败，回退到文件存储
            $this->pdo = null;
            error_log('Database connection failed: ' . $e->getMessage());
        }
    }
    
    /**
     * 检查数据库是否可用
     */
    public function isAvailable()
    {
        return $this->pdo !== null;
    }
    
    /**
     * 获取PDO实例
     */
    public function getPdo()
    {
        return $this->pdo;
    }
    
    /**
     * 执行查询
     */
    public function query($sql, $params = [])
    {
        if (!$this->isAvailable()) {
            throw new Exception('Database not available');
        }
        
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            error_log('Database query failed: ' . $e->getMessage());
            throw new Exception('Database query failed: ' . $e->getMessage());
        }
    }
    
    /**
     * 获取单行数据
     */
    public function fetchOne($sql, $params = [])
    {
        $stmt = $this->query($sql, $params);
        return $stmt->fetch();
    }
    
    /**
     * 获取多行数据
     */
    public function fetchAll($sql, $params = [])
    {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    /**
     * 插入数据
     */
    public function insert($table, $data)
    {
        if (!$this->isAvailable()) {
            throw new Exception('Database not available');
        }
        
        $columns = array_keys($data);
        $placeholders = array_map(function($col) { return ':' . $col; }, $columns);
        
        $sql = sprintf(
            'INSERT INTO %s (%s) VALUES (%s)',
            $table,
            implode(', ', $columns),
            implode(', ', $placeholders)
        );
        
        $this->query($sql, $data);
        return $this->pdo->lastInsertId();
    }
    
    /**
     * 更新数据
     */
    public function update($table, $data, $where, $whereParams = [])
    {
        if (!$this->isAvailable()) {
            throw new Exception('Database not available');
        }
        
        $setParts = [];
        foreach (array_keys($data) as $column) {
            $setParts[] = $column . ' = :' . $column;
        }
        
        $sql = sprintf(
            'UPDATE %s SET %s WHERE %s',
            $table,
            implode(', ', $setParts),
            $where
        );
        
        $params = array_merge($data, $whereParams);
        $stmt = $this->query($sql, $params);
        return $stmt->rowCount();
    }
    
    /**
     * 删除数据
     */
    public function delete($table, $where, $params = [])
    {
        if (!$this->isAvailable()) {
            throw new Exception('Database not available');
        }
        
        $sql = sprintf('DELETE FROM %s WHERE %s', $table, $where);
        $stmt = $this->query($sql, $params);
        return $stmt->rowCount();
    }
    
    /**
     * 开始事务
     */
    public function beginTransaction()
    {
        if ($this->isAvailable()) {
            return $this->pdo->beginTransaction();
        }
        return false;
    }
    
    /**
     * 提交事务
     */
    public function commit()
    {
        if ($this->isAvailable()) {
            return $this->pdo->commit();
        }
        return false;
    }
    
    /**
     * 回滚事务
     */
    public function rollback()
    {
        if ($this->isAvailable()) {
            return $this->pdo->rollback();
        }
        return false;
    }
    
    /**
     * 检查表是否存在
     */
    public function tableExists($tableName)
    {
        if (!$this->isAvailable()) {
            return false;
        }
        
        try {
            $sql = "SHOW TABLES LIKE :table_name";
            $result = $this->fetchOne($sql, ['table_name' => $tableName]);
            return $result !== false;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * 初始化数据库表
     */
    public function initializeTables()
    {
        if (!$this->isAvailable()) {
            return false;
        }
        
        $sqlFile = __DIR__ . '/../database/admin_tables.sql';
        if (!file_exists($sqlFile)) {
            return false;
        }
        
        try {
            $sql = file_get_contents($sqlFile);
            
            // 分割SQL语句
            $statements = array_filter(
                array_map('trim', explode(';', $sql)),
                function($stmt) {
                    return !empty($stmt) && !preg_match('/^--/', $stmt);
                }
            );
            
            $this->beginTransaction();
            
            foreach ($statements as $statement) {
                if (!empty($statement)) {
                    $this->pdo->exec($statement);
                }
            }
            
            $this->commit();
            return true;
        } catch (Exception $e) {
            $this->rollback();
            error_log('Database initialization failed: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取数据库状态信息
     */
    public function getStatus()
    {
        if (!$this->isAvailable()) {
            return [
                'connected' => false,
                'message' => 'Database not available'
            ];
        }
        
        try {
            $version = $this->fetchOne('SELECT VERSION() as version');
            $tables = $this->fetchAll('SHOW TABLES');
            
            return [
                'connected' => true,
                'version' => $version['version'],
                'tables_count' => count($tables),
                'message' => 'Database connected successfully'
            ];
        } catch (Exception $e) {
            return [
                'connected' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ];
        }
    }
}
?>
