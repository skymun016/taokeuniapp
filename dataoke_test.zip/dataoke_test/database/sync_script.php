<?php
/**
 * 大淘客数据同步脚本
 * 可以通过命令行或定时任务执行
 */

require_once 'DataokeSyncService.php';

// 数据库配置
$dbConfig = [
    'host' => 'localhost',
    'database' => 'dataoke_test', // 请根据实际情况修改
    'username' => 'root',
    'password' => '123456' // 请根据实际情况修改
];

// 大淘客配置
$dataokeConfig = [
    'app_key' => '68768ef94834a',
    'app_secret' => 'f5a5707c8d7b69b8dbad1ec15506c3b1',
    'pid' => 'mm_52162983_39758207_72877900030'
];

try {
    $syncService = new DataokeSyncService($dbConfig, $dataokeConfig);
    
    // 获取命令行参数
    $action = $argv[1] ?? 'help';
    
    echo "=== 大淘客数据同步工具 ===\n";
    echo "执行时间: " . date('Y-m-d H:i:s') . "\n";
    echo "操作类型: {$action}\n\n";
    
    switch ($action) {
        case 'full':
            echo "开始全量同步商品数据...\n";
            $syncService->syncAllGoods(50, 5); // 同步5页，每页50个商品
            break;
            
        case 'incremental':
            echo "开始增量同步商品数据...\n";
            $syncService->syncIncrementalGoods();
            break;
            
        case 'categories':
            echo "开始同步商品分类...\n";
            $syncService->syncCategories();
            break;
            
        case 'all':
            echo "开始完整同步（分类 + 商品）...\n";
            $syncService->syncCategories();
            sleep(2);
            $syncService->syncAllGoods(50, 3);
            break;
            
        case 'help':
        default:
            echo "使用方法:\n";
            echo "  php sync_script.php full         - 全量同步商品\n";
            echo "  php sync_script.php incremental  - 增量同步商品\n";
            echo "  php sync_script.php categories   - 同步分类\n";
            echo "  php sync_script.php all          - 完整同步\n";
            echo "  php sync_script.php help         - 显示帮助\n\n";
            echo "建议的使用策略:\n";
            echo "  1. 首次运行: php sync_script.php all\n";
            echo "  2. 定时任务: php sync_script.php incremental (每小时)\n";
            echo "  3. 分类更新: php sync_script.php categories (每天)\n";
            break;
    }
    
    echo "\n同步任务完成!\n";
    
} catch (Exception $e) {
    echo "同步失败: " . $e->getMessage() . "\n";
    exit(1);
}
?>
