<?php
/**
 * 大淘客数据查询服务
 * 为小程序提供快速的商品查询接口
 */

class DataokeQueryService
{
    private $pdo;

    public function __construct($dbConfig)
    {
        $dsn = "mysql:host={$dbConfig['host']};dbname={$dbConfig['database']};charset=utf8mb4";
        $this->pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
    }

    /**
     * 获取商品列表
     */
    public function getGoodsList($params = [])
    {
        $page = max(1, intval($params['page'] ?? 1));
        $pageSize = min(50, max(1, intval($params['pageSize'] ?? 20)));
        $offset = ($page - 1) * $pageSize;

        $where = ['is_live = 1'];
        $bindings = [];

        // 分类筛选
        if (!empty($params['cid'])) {
            $where[] = 'cid = ?';
            $bindings[] = $params['cid'];
        }

        // 价格筛选
        if (!empty($params['minPrice'])) {
            $where[] = 'actual_price >= ?';
            $bindings[] = $params['minPrice'];
        }
        if (!empty($params['maxPrice'])) {
            $where[] = 'actual_price <= ?';
            $bindings[] = $params['maxPrice'];
        }

        // 关键词搜索
        if (!empty($params['keyword'])) {
            $where[] = '(title LIKE ? OR dtitle LIKE ? OR brand_name LIKE ?)';
            $keyword = '%' . $params['keyword'] . '%';
            $bindings[] = $keyword;
            $bindings[] = $keyword;
            $bindings[] = $keyword;
        }

        // 排序
        $orderBy = 'month_sales DESC, commission_rate DESC';
        switch ($params['sort'] ?? '') {
            case 'price_asc':
                $orderBy = 'actual_price ASC';
                break;
            case 'price_desc':
                $orderBy = 'actual_price DESC';
                break;
            case 'commission':
                $orderBy = 'commission_rate DESC';
                break;
            case 'sales':
                $orderBy = 'month_sales DESC';
                break;
        }

        $whereClause = implode(' AND ', $where);
        
        // 查询总数
        $countSql = "SELECT COUNT(*) as total FROM dtk_goods WHERE {$whereClause}";
        $countStmt = $this->pdo->prepare($countSql);
        $countStmt->execute($bindings);
        $total = $countStmt->fetch()['total'];

        // 查询数据
        $sql = "SELECT 
                    goods_id, title, dtitle, original_price, actual_price, coupon_price,
                    commission_rate, month_sales, main_pic, shop_name, shop_type,
                    brand_name, coupon_start_time, coupon_end_time, item_link
                FROM dtk_goods 
                WHERE {$whereClause} 
                ORDER BY {$orderBy} 
                LIMIT {$offset}, {$pageSize}";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($bindings);
        $goods = $stmt->fetchAll();

        return [
            'success' => true,
            'data' => [
                'list' => $goods,
                'total' => $total,
                'page' => $page,
                'pageSize' => $pageSize,
                'totalPages' => ceil($total / $pageSize)
            ]
        ];
    }

    /**
     * 获取商品详情
     */
    public function getGoodsDetail($goodsId)
    {
        $sql = "SELECT * FROM dtk_goods WHERE goods_id = ? AND is_live = 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$goodsId]);
        $goods = $stmt->fetch();

        if (!$goods) {
            return [
                'success' => false,
                'message' => '商品不存在或已下架'
            ];
        }

        // 解析JSON字段
        if ($goods['detail_pics']) {
            $goods['detail_pics'] = json_decode($goods['detail_pics'], true);
        }
        if ($goods['subcid']) {
            $goods['subcid'] = json_decode($goods['subcid'], true);
        }

        return [
            'success' => true,
            'data' => $goods
        ];
    }

    /**
     * 搜索商品
     */
    public function searchGoods($keyword, $params = [])
    {
        $params['keyword'] = $keyword;
        return $this->getGoodsList($params);
    }

    /**
     * 获取分类列表
     */
    public function getCategories($parentId = 0)
    {
        $sql = "SELECT * FROM dtk_categories WHERE parent_id = ? AND is_active = 1 ORDER BY sort_order, id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$parentId]);
        $categories = $stmt->fetchAll();

        return [
            'success' => true,
            'data' => $categories
        ];
    }

    /**
     * 获取热门商品
     */
    public function getHotGoods($limit = 20)
    {
        $sql = "SELECT 
                    goods_id, title, dtitle, original_price, actual_price, coupon_price,
                    commission_rate, month_sales, main_pic, shop_name, brand_name
                FROM dtk_goods 
                WHERE is_live = 1 AND month_sales > 100
                ORDER BY month_sales DESC, commission_rate DESC 
                LIMIT ?";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$limit]);
        $goods = $stmt->fetchAll();

        return [
            'success' => true,
            'data' => $goods
        ];
    }

    /**
     * 获取高佣商品
     */
    public function getHighCommissionGoods($limit = 20)
    {
        $sql = "SELECT 
                    goods_id, title, dtitle, original_price, actual_price, coupon_price,
                    commission_rate, month_sales, main_pic, shop_name, brand_name
                FROM dtk_goods 
                WHERE is_live = 1 AND commission_rate >= 10
                ORDER BY commission_rate DESC, month_sales DESC 
                LIMIT ?";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$limit]);
        $goods = $stmt->fetchAll();

        return [
            'success' => true,
            'data' => $goods
        ];
    }

    /**
     * 获取推广链接（带缓存）
     */
    public function getPromotionLink($goodsId, $pid)
    {
        // 先查缓存
        $sql = "SELECT * FROM dtk_promotion_links 
                WHERE goods_id = ? AND pid = ? AND (expire_time IS NULL OR expire_time > NOW())";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$goodsId, $pid]);
        $cached = $stmt->fetch();

        if ($cached) {
            return [
                'success' => true,
                'data' => [
                    'item_url' => $cached['item_url'],
                    'short_url' => $cached['short_url'],
                    'kuaizhan_url' => $cached['kuaizhan_url'],
                    'tpwd' => $cached['tpwd'],
                    'long_tpwd' => $cached['long_tpwd'],
                    'commission_rate' => $cached['commission_rate'],
                    'from_cache' => true
                ]
            ];
        }

        return [
            'success' => false,
            'message' => '推广链接未缓存，请通过API生成'
        ];
    }

    /**
     * 缓存推广链接
     */
    public function cachePromotionLink($goodsId, $pid, $linkData, $expireHours = 24)
    {
        $expireTime = date('Y-m-d H:i:s', time() + $expireHours * 3600);
        
        $sql = "INSERT INTO dtk_promotion_links 
                (goods_id, pid, item_url, short_url, kuaizhan_url, tpwd, long_tpwd, 
                 commission_rate, coupon_click_url, expire_time) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                item_url = VALUES(item_url),
                short_url = VALUES(short_url),
                kuaizhan_url = VALUES(kuaizhan_url),
                tpwd = VALUES(tpwd),
                long_tpwd = VALUES(long_tpwd),
                commission_rate = VALUES(commission_rate),
                expire_time = VALUES(expire_time),
                update_time = NOW()";

        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            $goodsId,
            $pid,
            $linkData['itemUrl'] ?? '',
            $linkData['shortUrl'] ?? '',
            $linkData['kuaiZhanUrl'] ?? '',
            $linkData['tpwd'] ?? '',
            $linkData['longTpwd'] ?? '',
            $linkData['maxCommissionRate'] ?? 0,
            $linkData['couponClickUrl'] ?? '',
            $expireTime
        ]);
    }

    /**
     * 获取统计信息
     */
    public function getStats()
    {
        $stats = [];

        // 商品总数
        $sql = "SELECT COUNT(*) as total FROM dtk_goods WHERE is_live = 1";
        $stmt = $this->pdo->query($sql);
        $stats['total_goods'] = $stmt->fetch()['total'];

        // 分类总数
        $sql = "SELECT COUNT(*) as total FROM dtk_categories WHERE is_active = 1";
        $stmt = $this->pdo->query($sql);
        $stats['total_categories'] = $stmt->fetch()['total'];

        // 最后同步时间
        $sql = "SELECT MAX(sync_time) as last_sync FROM dtk_goods";
        $stmt = $this->pdo->query($sql);
        $stats['last_sync_time'] = $stmt->fetch()['last_sync'];

        // 今日新增商品
        $sql = "SELECT COUNT(*) as today_new FROM dtk_goods 
                WHERE DATE(create_time) = CURDATE()";
        $stmt = $this->pdo->query($sql);
        $stats['today_new_goods'] = $stmt->fetch()['today_new'];

        return [
            'success' => true,
            'data' => $stats
        ];
    }
}
?>
