<?php
/**
 * 大淘客数据同步服务
 * 负责从大淘客API拉取数据并存储到本地数据库
 */

require_once '../DataokeAdapter.php';

class DataokeSyncService
{
    private $pdo;
    private $adapter;
    private $config;

    public function __construct($dbConfig, $dataokeConfig)
    {
        // 初始化数据库连接
        $dsn = "mysql:host={$dbConfig['host']};dbname={$dbConfig['database']};charset=utf8mb4";
        $this->pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);

        // 初始化大淘客适配器
        $this->adapter = new DataokeAdapter(
            $dataokeConfig['app_key'],
            $dataokeConfig['app_secret'],
            $dataokeConfig['pid']
        );

        $this->config = $dataokeConfig;
    }

    /**
     * 全量同步商品数据
     */
    public function syncAllGoods($pageSize = 100, $maxPages = 10)
    {
        $logId = $this->startSyncLog('goods_list', ['pageSize' => $pageSize, 'maxPages' => $maxPages]);
        
        try {
            $totalCount = 0;
            $successCount = 0;
            $errorCount = 0;

            for ($page = 1; $page <= $maxPages; $page++) {
                echo "正在同步第 {$page} 页商品...\n";
                
                $result = $this->adapter->getGoodsList([
                    'pageId' => $page,
                    'pageSize' => $pageSize
                ]);

                if (!$result['success']) {
                    echo "获取第 {$page} 页失败: {$result['message']}\n";
                    $errorCount++;
                    continue;
                }

                $goods = $result['data']['list'];
                $totalCount += count($goods);

                foreach ($goods as $item) {
                    if ($this->saveGoods($item)) {
                        $successCount++;
                    } else {
                        $errorCount++;
                    }
                }

                // 避免API调用过于频繁
                sleep(1);
            }

            $this->completeSyncLog($logId, 2, $totalCount, $successCount, $errorCount);
            echo "全量同步完成: 总计 {$totalCount}, 成功 {$successCount}, 失败 {$errorCount}\n";
            
            return true;

        } catch (Exception $e) {
            $this->completeSyncLog($logId, 3, $totalCount, $successCount, $errorCount, $e->getMessage());
            echo "同步异常: " . $e->getMessage() . "\n";
            return false;
        }
    }

    /**
     * 增量同步商品数据
     */
    public function syncIncrementalGoods()
    {
        $lastSyncTime = $this->getConfig('last_sync_time');
        $startTime = $lastSyncTime ? $lastSyncTime : date('Y-m-d H:i:s', strtotime('-1 hour'));
        $endTime = date('Y-m-d H:i:s');

        $logId = $this->startSyncLog('pull_by_time', [
            'startTime' => $startTime,
            'endTime' => $endTime
        ]);

        try {
            $totalCount = 0;
            $successCount = 0;
            $errorCount = 0;
            $pageId = '1';

            do {
                $result = $this->adapter->pullGoodsByTime([
                    'pageId' => $pageId,
                    'pageSize' => 100,
                    'startTime' => $startTime,
                    'endTime' => $endTime
                ]);

                if (!$result['success']) {
                    echo "增量同步失败: {$result['message']}\n";
                    break;
                }

                $goods = $result['data']['list'] ?? [];
                $totalCount += count($goods);

                foreach ($goods as $item) {
                    if ($this->saveGoods($item)) {
                        $successCount++;
                    } else {
                        $errorCount++;
                    }
                }

                // 获取下一页ID
                $pageId = $result['data']['pageId'] ?? null;
                
                sleep(1); // 避免API调用过于频繁

            } while (!empty($pageId) && !empty($goods));

            // 更新最后同步时间
            $this->setConfig('last_sync_time', $endTime);

            $this->completeSyncLog($logId, 2, $totalCount, $successCount, $errorCount);
            echo "增量同步完成: 总计 {$totalCount}, 成功 {$successCount}, 失败 {$errorCount}\n";
            
            return true;

        } catch (Exception $e) {
            $this->completeSyncLog($logId, 3, $totalCount, $successCount, $errorCount, $e->getMessage());
            echo "增量同步异常: " . $e->getMessage() . "\n";
            return false;
        }
    }

    /**
     * 同步商品分类
     */
    public function syncCategories()
    {
        $logId = $this->startSyncLog('categories');
        
        try {
            $result = $this->adapter->getSuperCategory();
            
            if (!$result['success']) {
                throw new Exception("获取分类失败: " . $result['message']);
            }

            $categories = $result['data'];
            $successCount = 0;

            foreach ($categories as $category) {
                if ($this->saveCategory($category)) {
                    $successCount++;
                }
            }

            $this->completeSyncLog($logId, 2, count($categories), $successCount, 0);
            echo "分类同步完成: 总计 " . count($categories) . ", 成功 {$successCount}\n";
            
            return true;

        } catch (Exception $e) {
            $this->completeSyncLog($logId, 3, 0, 0, 1, $e->getMessage());
            echo "分类同步异常: " . $e->getMessage() . "\n";
            return false;
        }
    }

    /**
     * 保存商品数据
     */
    private function saveGoods($item)
    {
        try {
            $sql = "INSERT INTO dtk_goods (
                goods_id, item_id, title, dtitle, original_price, actual_price,
                coupon_price, coupon_conditions, coupon_start_time, coupon_end_time,
                coupon_total_num, coupon_remain_count, commission_rate, commission_type,
                month_sales, two_hours_sales, daily_sales, main_pic, marketing_main_pic,
                detail_pics, item_link, coupon_link, shop_name, shop_type, shop_level,
                seller_id, brand_name, brand_id, cid, subcid, tbcid,
                desc_score, service_score, ship_score, is_brand, hot_push,
                activity_type, activity_start_time, activity_end_time,
                yunfeixian, freeship_remote_district, sync_time
            ) VALUES (
                :goods_id, :item_id, :title, :dtitle, :original_price, :actual_price,
                :coupon_price, :coupon_conditions, :coupon_start_time, :coupon_end_time,
                :coupon_total_num, :coupon_remain_count, :commission_rate, :commission_type,
                :month_sales, :two_hours_sales, :daily_sales, :main_pic, :marketing_main_pic,
                :detail_pics, :item_link, :coupon_link, :shop_name, :shop_type, :shop_level,
                :seller_id, :brand_name, :brand_id, :cid, :subcid, :tbcid,
                :desc_score, :service_score, :ship_score, :is_brand, :hot_push,
                :activity_type, :activity_start_time, :activity_end_time,
                :yunfeixian, :freeship_remote_district, NOW()
            ) ON DUPLICATE KEY UPDATE
                title = VALUES(title),
                actual_price = VALUES(actual_price),
                coupon_price = VALUES(coupon_price),
                month_sales = VALUES(month_sales),
                sync_time = NOW()";

            $stmt = $this->pdo->prepare($sql);
            
            return $stmt->execute([
                'goods_id' => $item['goodsId'],
                'item_id' => $item['itemId'] ?? null,
                'title' => $item['title'],
                'dtitle' => $item['dtitle'] ?? null,
                'original_price' => $item['originalPrice'] ?? null,
                'actual_price' => $item['actualPrice'] ?? null,
                'coupon_price' => $item['couponPrice'] ?? 0,
                'coupon_conditions' => $item['couponConditions'] ?? null,
                'coupon_start_time' => $item['couponStartTime'] ?? null,
                'coupon_end_time' => $item['couponEndTime'] ?? null,
                'coupon_total_num' => $item['couponTotalNum'] ?? 0,
                'coupon_remain_count' => $item['couponRemainCount'] ?? 0,
                'commission_rate' => $item['commissionRate'] ?? null,
                'commission_type' => $item['commissionType'] ?? null,
                'month_sales' => $item['monthSales'] ?? 0,
                'two_hours_sales' => $item['twoHoursSales'] ?? 0,
                'daily_sales' => $item['dailySales'] ?? 0,
                'main_pic' => $item['mainPic'] ?? null,
                'marketing_main_pic' => $item['marketingMainPic'] ?? null,
                'detail_pics' => isset($item['detailPics']) ? json_encode($item['detailPics']) : null,
                'item_link' => $item['itemLink'] ?? null,
                'coupon_link' => $item['couponLink'] ?? null,
                'shop_name' => $item['shopName'] ?? null,
                'shop_type' => $item['shopType'] ?? null,
                'shop_level' => $item['shopLevel'] ?? null,
                'seller_id' => $item['sellerId'] ?? null,
                'brand_name' => $item['brandName'] ?? null,
                'brand_id' => $item['brandId'] ?? null,
                'cid' => $item['cid'] ?? null,
                'subcid' => isset($item['subcid']) ? json_encode($item['subcid']) : null,
                'tbcid' => $item['tbcid'] ?? null,
                'desc_score' => $item['descScore'] ?? null,
                'service_score' => $item['serviceScore'] ?? null,
                'ship_score' => $item['shipScore'] ?? null,
                'is_brand' => $item['brand'] ?? 0,
                'hot_push' => $item['hotPush'] ?? 0,
                'activity_type' => $item['activityType'] ?? null,
                'activity_start_time' => $item['activityStartTime'] ?? null,
                'activity_end_time' => $item['activityEndTime'] ?? null,
                'yunfeixian' => $item['yunfeixian'] ?? 0,
                'freeship_remote_district' => $item['freeshipRemoteDistrict'] ?? 0
            ]);

        } catch (Exception $e) {
            echo "保存商品失败 {$item['goodsId']}: " . $e->getMessage() . "\n";
            return false;
        }
    }

    /**
     * 保存分类数据
     */
    private function saveCategory($category)
    {
        try {
            $sql = "INSERT INTO dtk_categories (cid, cname, parent_id, level, sort_order) 
                    VALUES (:cid, :cname, :parent_id, :level, :sort_order)
                    ON DUPLICATE KEY UPDATE cname = VALUES(cname)";

            $stmt = $this->pdo->prepare($sql);
            
            return $stmt->execute([
                'cid' => $category['cid'],
                'cname' => $category['cname'],
                'parent_id' => $category['pid'] ?? 0,
                'level' => 1,
                'sort_order' => 0
            ]);

        } catch (Exception $e) {
            echo "保存分类失败 {$category['cid']}: " . $e->getMessage() . "\n";
            return false;
        }
    }

    // 辅助方法
    private function startSyncLog($syncType, $params = [])
    {
        $sql = "INSERT INTO dtk_sync_logs (sync_type, start_time, params) VALUES (?, NOW(), ?)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$syncType, json_encode($params)]);
        return $this->pdo->lastInsertId();
    }

    private function completeSyncLog($logId, $status, $totalCount, $successCount, $errorCount, $errorMessage = null)
    {
        $sql = "UPDATE dtk_sync_logs SET end_time = NOW(), status = ?, total_count = ?, 
                success_count = ?, error_count = ?, error_message = ? WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$status, $totalCount, $successCount, $errorCount, $errorMessage, $logId]);
    }

    private function getConfig($key)
    {
        $sql = "SELECT config_value FROM dtk_config WHERE config_key = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        return $result ? $result['config_value'] : null;
    }

    private function setConfig($key, $value)
    {
        $sql = "INSERT INTO dtk_config (config_key, config_value) VALUES (?, ?) 
                ON DUPLICATE KEY UPDATE config_value = VALUES(config_value)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$key, $value]);
    }
}
?>
