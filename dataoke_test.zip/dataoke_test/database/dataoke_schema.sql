-- 大淘客商品数据库设计
-- 创建时间: 2025-07-16
-- 说明: 用于存储大淘客商品信息，支持定时拉取和本地缓存

-- 1. 商品基础信息表
CREATE TABLE `dtk_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `goods_id` varchar(100) NOT NULL COMMENT '大淘客商品ID',
  `item_id` varchar(100) DEFAULT NULL COMMENT '淘宝商品ID',
  `title` varchar(500) NOT NULL COMMENT '商品标题',
  `dtitle` varchar(500) DEFAULT NULL COMMENT '推广标题',
  `original_price` decimal(10,2) DEFAULT NULL COMMENT '原价',
  `actual_price` decimal(10,2) DEFAULT NULL COMMENT '券后价',
  `coupon_price` decimal(10,2) DEFAULT 0.00 COMMENT '优惠券金额',
  `coupon_conditions` varchar(50) DEFAULT NULL COMMENT '优惠券使用条件',
  `coupon_start_time` datetime DEFAULT NULL COMMENT '优惠券开始时间',
  `coupon_end_time` datetime DEFAULT NULL COMMENT '优惠券结束时间',
  `coupon_total_num` int(11) DEFAULT 0 COMMENT '优惠券总数量',
  `coupon_remain_count` int(11) DEFAULT 0 COMMENT '优惠券剩余数量',
  `commission_rate` decimal(5,2) DEFAULT NULL COMMENT '佣金比例',
  `commission_type` tinyint(4) DEFAULT NULL COMMENT '佣金类型',
  `month_sales` int(11) DEFAULT 0 COMMENT '月销量',
  `two_hours_sales` int(11) DEFAULT 0 COMMENT '2小时销量',
  `daily_sales` int(11) DEFAULT 0 COMMENT '日销量',
  `main_pic` varchar(500) DEFAULT NULL COMMENT '主图链接',
  `marketing_main_pic` varchar(500) DEFAULT NULL COMMENT '营销主图',
  `detail_pics` text COMMENT '详情图片JSON',
  `item_link` varchar(1000) DEFAULT NULL COMMENT '商品链接',
  `coupon_link` varchar(1000) DEFAULT NULL COMMENT '优惠券链接',
  `shop_name` varchar(200) DEFAULT NULL COMMENT '店铺名称',
  `shop_type` tinyint(4) DEFAULT NULL COMMENT '店铺类型 1-天猫 0-淘宝',
  `shop_level` int(11) DEFAULT NULL COMMENT '店铺等级',
  `seller_id` varchar(100) DEFAULT NULL COMMENT '卖家ID',
  `brand_name` varchar(200) DEFAULT NULL COMMENT '品牌名称',
  `brand_id` int(11) DEFAULT NULL COMMENT '品牌ID',
  `cid` int(11) DEFAULT NULL COMMENT '一级分类ID',
  `subcid` varchar(200) DEFAULT NULL COMMENT '二级分类ID JSON',
  `tbcid` int(11) DEFAULT NULL COMMENT '淘宝分类ID',
  `desc_score` decimal(3,1) DEFAULT NULL COMMENT '描述评分',
  `service_score` decimal(3,1) DEFAULT NULL COMMENT '服务评分',
  `ship_score` decimal(3,1) DEFAULT NULL COMMENT '物流评分',
  `is_brand` tinyint(1) DEFAULT 0 COMMENT '是否品牌商品',
  `is_live` tinyint(1) DEFAULT 1 COMMENT '是否有效 1-有效 0-失效',
  `hot_push` int(11) DEFAULT 0 COMMENT '热推值',
  `activity_type` tinyint(4) DEFAULT NULL COMMENT '活动类型',
  `activity_start_time` datetime DEFAULT NULL COMMENT '活动开始时间',
  `activity_end_time` datetime DEFAULT NULL COMMENT '活动结束时间',
  `yunfeixian` tinyint(1) DEFAULT 0 COMMENT '是否运费险',
  `freeship_remote_district` tinyint(1) DEFAULT 0 COMMENT '偏远地区包邮',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `sync_time` datetime DEFAULT NULL COMMENT '同步时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_goods_id` (`goods_id`),
  KEY `idx_cid` (`cid`),
  KEY `idx_actual_price` (`actual_price`),
  KEY `idx_commission_rate` (`commission_rate`),
  KEY `idx_month_sales` (`month_sales`),
  KEY `idx_is_live` (`is_live`),
  KEY `idx_sync_time` (`sync_time`),
  KEY `idx_title` (`title`(100)),
  KEY `idx_brand_name` (`brand_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='大淘客商品信息表';

-- 2. 商品分类表
CREATE TABLE `dtk_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL COMMENT '分类ID',
  `cname` varchar(100) NOT NULL COMMENT '分类名称',
  `parent_id` int(11) DEFAULT 0 COMMENT '父分类ID',
  `level` tinyint(4) DEFAULT 1 COMMENT '分类层级',
  `sort_order` int(11) DEFAULT 0 COMMENT '排序',
  `is_active` tinyint(1) DEFAULT 1 COMMENT '是否启用',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cid` (`cid`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品分类表';

-- 3. 推广链接缓存表
CREATE TABLE `dtk_promotion_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` varchar(100) NOT NULL COMMENT '商品ID',
  `pid` varchar(100) NOT NULL COMMENT '推广位ID',
  `item_url` varchar(1000) DEFAULT NULL COMMENT '推广链接',
  `short_url` varchar(500) DEFAULT NULL COMMENT '短链接',
  `kuaizhan_url` varchar(500) DEFAULT NULL COMMENT '快站链接',
  `tpwd` varchar(50) DEFAULT NULL COMMENT '淘口令',
  `long_tpwd` varchar(200) DEFAULT NULL COMMENT '长淘口令',
  `commission_rate` decimal(5,2) DEFAULT NULL COMMENT '佣金比例',
  `coupon_click_url` varchar(1000) DEFAULT NULL COMMENT '优惠券链接',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_goods_pid` (`goods_id`, `pid`),
  KEY `idx_expire_time` (`expire_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='推广链接缓存表';

-- 4. 同步任务记录表
CREATE TABLE `dtk_sync_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sync_type` varchar(50) NOT NULL COMMENT '同步类型: goods_list, pull_by_time, categories',
  `start_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `status` tinyint(4) DEFAULT 1 COMMENT '状态: 1-进行中 2-成功 3-失败',
  `total_count` int(11) DEFAULT 0 COMMENT '总数量',
  `success_count` int(11) DEFAULT 0 COMMENT '成功数量',
  `error_count` int(11) DEFAULT 0 COMMENT '失败数量',
  `error_message` text COMMENT '错误信息',
  `params` text COMMENT '同步参数JSON',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sync_type` (`sync_type`),
  KEY `idx_start_time` (`start_time`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='同步任务记录表';

-- 5. 系统配置表
CREATE TABLE `dtk_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) NOT NULL COMMENT '配置键',
  `config_value` text COMMENT '配置值',
  `description` varchar(500) DEFAULT NULL COMMENT '配置说明',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统配置表';

-- 插入默认配置
INSERT INTO `dtk_config` (`config_key`, `config_value`, `description`) VALUES
('last_sync_time', '', '最后同步时间'),
('sync_interval', '3600', '同步间隔(秒)'),
('link_cache_time', '86400', '推广链接缓存时间(秒)'),
('api_app_key', '68768ef94834a', '大淘客APP KEY'),
('api_app_secret', 'f5a5707c8d7b69b8dbad1ec15506c3b1', '大淘客APP SECRET'),
('api_pid', 'mm_52162983_39758207_72877900030', '推广位ID');
