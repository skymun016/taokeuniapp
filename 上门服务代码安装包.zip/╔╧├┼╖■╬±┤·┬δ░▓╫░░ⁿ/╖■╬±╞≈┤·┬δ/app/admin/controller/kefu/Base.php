<?php

namespace app\admin\controller\kefu;

class Base extends \app\admin\controller\Base
{

}
