<?php

namespace app\admin\controller;

class UploadController extends Base
{

	
}
