<?php

namespace app\index\controller;

class UploadController extends Base
{

	function index()
	{
		return $this->upload();
	}
}
