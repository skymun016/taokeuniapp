<?php

namespace app\index\controller\kefu;

class Base extends \app\index\controller\Base
{

}
