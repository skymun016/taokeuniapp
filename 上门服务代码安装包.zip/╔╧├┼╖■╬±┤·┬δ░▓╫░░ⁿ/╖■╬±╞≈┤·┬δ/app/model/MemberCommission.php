<?php
namespace app\model;

use think\Model;

class MemberCommission extends Model
{

    protected $connection = 'mysql';

    protected $pk = 'id';

    protected $name = 'member_commission';

}
