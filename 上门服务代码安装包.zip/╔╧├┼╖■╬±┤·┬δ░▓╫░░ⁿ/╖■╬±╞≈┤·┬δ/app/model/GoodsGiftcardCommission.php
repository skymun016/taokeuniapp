<?php
namespace app\model;

use think\Model;

class GoodsGiftcardCommission extends Model
{

    protected $connection = 'mysql';

    protected $pk = 'id';

    protected $name = 'goods_giftcard_commission';

}
