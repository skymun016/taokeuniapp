<?php 

namespace app\model;
use think\Model;

class Upload extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'upload_id';

 	protected $name = 'upload';
 

}

