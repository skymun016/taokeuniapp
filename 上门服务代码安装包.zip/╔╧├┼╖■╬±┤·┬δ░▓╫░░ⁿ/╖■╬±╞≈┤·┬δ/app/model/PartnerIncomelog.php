<?php
namespace app\model;
use think\Model;

class PartnerIncomelog extends Model
{

    protected $connection = 'mysql';

    protected $pk = 'id';

    protected $name = 'partner_incomelog';

}
