<?php
namespace app\model;

use think\Model;

class GoodsToCategory extends Model
{

    protected $connection = 'mysql';

    protected $pk = 'id';

    protected $name = 'goods_to_category';

}
