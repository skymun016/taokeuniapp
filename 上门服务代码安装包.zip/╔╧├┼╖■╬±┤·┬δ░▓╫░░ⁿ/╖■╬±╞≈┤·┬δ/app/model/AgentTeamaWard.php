<?php

namespace app\model;

use think\Model;

class AgentTeamaWard extends Model
{

	protected $connection = 'mysql';

	protected $pk = 'id';

	protected $name = 'agent_teama_ward';

}
