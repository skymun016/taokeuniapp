<?php 
namespace app\model;
use think\Model;

class FilesCate extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'files_cate';

}

