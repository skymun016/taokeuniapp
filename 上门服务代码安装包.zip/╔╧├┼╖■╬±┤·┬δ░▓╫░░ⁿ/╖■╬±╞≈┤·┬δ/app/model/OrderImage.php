<?php
namespace app\model;

use think\Model;

class OrderImage extends Model
{

    protected $connection = 'mysql';

    protected $pk = 'id';

    protected $name = 'order_image';

}
