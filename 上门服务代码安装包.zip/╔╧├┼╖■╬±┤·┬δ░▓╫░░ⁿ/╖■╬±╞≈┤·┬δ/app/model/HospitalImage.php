<?php
namespace app\model;
use think\Model;

class HospitalImage extends Model
{
    protected $connection = 'mysql';

    protected $pk = 'id';

    protected $name = 'hospital_image';

}
