<?php

namespace app\model;

use think\Model;

class DictType extends Model
{

	protected $connection = 'mysql';

	protected $pk = 'id';

	protected $name = 'dict_type';

}
