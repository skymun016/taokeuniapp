<?php 

namespace app\model;
use think\Model;

class UsersSessions extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'users_sessions';
 

}

