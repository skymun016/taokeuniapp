<?php
namespace app\model;

use think\Model;

class GoodsDescription extends Model
{

    protected $connection = 'mysql';

    protected $pk = 'id';

    protected $name = 'goods_description';

}
