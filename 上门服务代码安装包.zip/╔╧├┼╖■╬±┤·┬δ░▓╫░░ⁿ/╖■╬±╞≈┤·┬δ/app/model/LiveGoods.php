<?php

namespace app\model;

use think\Model;

class LiveGoods extends Model
{

    protected $connection = 'mysql';

    protected $pk = 'id';

    protected $name = 'live_goods';
}
