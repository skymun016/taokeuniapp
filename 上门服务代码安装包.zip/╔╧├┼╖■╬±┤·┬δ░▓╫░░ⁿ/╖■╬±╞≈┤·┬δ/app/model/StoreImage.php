<?php
namespace app\model;
use think\Model;

class StoreImage extends Model
{
    protected $connection = 'mysql';

    protected $pk = 'id';

    protected $name = 'store_image';

}
