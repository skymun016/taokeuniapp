<?php

namespace app\model;

use think\Model;

class RotarytableLog extends Model
{
    protected $connection = 'mysql';

    protected $pk = 'id';

    protected $name = 'rotarytable_log';
}
