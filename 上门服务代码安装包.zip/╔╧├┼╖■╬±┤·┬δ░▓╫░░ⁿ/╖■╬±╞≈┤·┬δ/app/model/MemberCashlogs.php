<?php
namespace app\model;

use think\Model;

class MemberCashlogs extends Model
{

	protected $connection = 'mysql';

	protected $pk = 'id';

	protected $name = 'member_cashlogs';

}
