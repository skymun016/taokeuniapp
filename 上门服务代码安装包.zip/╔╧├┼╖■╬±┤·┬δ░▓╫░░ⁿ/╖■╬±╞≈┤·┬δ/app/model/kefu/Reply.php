<?php 
namespace app\model\kefu;
use think\Model;

class Reply extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'kefu_reply';


}