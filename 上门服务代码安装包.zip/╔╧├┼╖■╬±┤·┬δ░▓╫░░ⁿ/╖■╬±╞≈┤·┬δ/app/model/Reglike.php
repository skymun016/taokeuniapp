<?php

namespace app\model;

use think\Model;

class Reglike extends Model
{

    protected $connection = 'mysql';

    protected $pk = 'id';

    protected $name = 'reglike';
}
