<?php

namespace app\model;

use think\Model;

class OrderTimescard extends Model
{

	protected $connection = 'mysql';

	protected $pk = 'id';

	protected $name = 'order_timescard';
}
