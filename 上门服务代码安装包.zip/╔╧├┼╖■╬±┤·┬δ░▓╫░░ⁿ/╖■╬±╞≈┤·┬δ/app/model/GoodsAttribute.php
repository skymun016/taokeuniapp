<?php
namespace app\model;

use think\Model;

class GoodsAttribute extends Model
{

	protected $connection = 'mysql';

	protected $pk = 'id';

	protected $name = 'goods_attribute';

}
