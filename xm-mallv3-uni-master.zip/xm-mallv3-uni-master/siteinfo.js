var siteinfo = {
	"uniacid": "13",
	"acid": "13",
	"multiid": "0",
	"version": "1",
	"siteroot": "https://dao.thinkoto.com/app/index.php",
	"design_method": "2"
}
module.exports = siteinfo