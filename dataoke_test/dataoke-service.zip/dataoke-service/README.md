# 大淘客独立服务端部署指南

## 📋 项目概述

这是一个完全独立的大淘客服务端系统，为小程序端提供大淘客商品数据API接口。该系统基于我们已经成功测试的大淘客官方SDK构建，提供稳定可靠的商品数据服务。

## 🏗️ 系统架构

```
小程序端 ←→ 大淘客独立服务端 ←→ 大淘客官方API
```

## 📁 目录结构

```
dataoke-service/
├── index.php              # 入口文件和路由
├── config/
│   └── config.php         # 配置文件
├── lib/
│   ├── common.php         # 公共函数库
│   └── DataokeAdapter.php # 大淘客适配器
├── api/
│   ├── goods.php          # 商品接口
│   ├── category.php       # 分类接口
│   ├── search.php         # 搜索接口
│   └── test.php           # 测试接口
├── openapi-sdk-php/       # 大淘客官方SDK
├── cache/                 # 缓存目录（自动创建）
├── logs/                  # 日志目录（自动创建）
└── README.md              # 部署文档
```

## 🔧 环境要求

### 服务器要求
- **PHP**: 7.4 或更高版本
- **Web服务器**: Nginx 或 Apache
- **扩展**: curl, json, mbstring
- **权限**: 可写入缓存和日志目录

### 推荐配置
- **内存**: 512MB 或更高
- **存储**: 1GB 可用空间
- **带宽**: 10Mbps 或更高

## 🚀 部署步骤

### 1. 上传文件
将整个 `dataoke-service` 目录上传到您的服务器。

```bash
# 示例：上传到服务器的 /var/www/html/ 目录
scp -r dataoke-service/ user@your-server:/var/www/html/
```

### 2. 设置目录权限
```bash
# 进入项目目录
cd /var/www/html/dataoke-service

# 设置缓存和日志目录权限
chmod 755 cache/
chmod 755 logs/
chown -R www-data:www-data cache/ logs/
```

### 3. 配置Web服务器

#### Nginx 配置示例
```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/html/dataoke-service;
    index index.php;

    # 处理API路由
    location /api/ {
        try_files $uri $uri/ /index.php?$query_string;
    }

    # 处理PHP文件
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }

    # 安全设置
    location ~ /\. {
        deny all;
    }
    
    location ~* \.(log|cache)$ {
        deny all;
    }
}
```

#### Apache 配置示例
在项目根目录创建 `.htaccess` 文件：
```apache
RewriteEngine On

# API路由重写
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^api/(.*)$ index.php [QSA,L]

# 安全设置
<Files ~ "\.(log|cache)$">
    Order allow,deny
    Deny from all
</Files>

<Files ~ "^\.">
    Order allow,deny
    Deny from all
</Files>
```

### 4. 配置大淘客凭证
编辑 `config/config.php` 文件，确认大淘客配置信息：

```php
// 大淘客API配置
define('DATAOKE_CONFIG', [
    'app_key' => '678fc81d72259',
    'app_secret' => '6fd2acba8bce6c039ab276256f003ced',
    'pid' => 'mm_52162983_2267550029_112173400498',
    'version' => 'v1.2.4'
]);
```

### 5. 配置CORS（如果需要）
如果小程序端和服务端不在同一域名，需要配置CORS：

```php
// 在 config/config.php 中修改
define('CORS_CONFIG', [
    'allow_origin' => 'https://your-miniprogram-domain.com', // 设置具体域名
    'allow_methods' => 'GET, POST, OPTIONS',
    'allow_headers' => 'Content-Type, Authorization, X-Requested-With',
    'allow_credentials' => 'false'
]);
```

## 🧪 测试部署

### 1. 访问服务文档
在浏览器中访问：`http://your-domain.com/dataoke-service/`

应该看到API文档页面，显示服务状态为"运行中"。

### 2. 测试API连接
访问：`http://your-domain.com/dataoke-service/api/test`

正常响应示例：
```json
{
    "code": 0,
    "message": "服务运行正常",
    "timestamp": 1642147200,
    "data": {
        "service_status": "running",
        "dataoke_status": "connected",
        "server_time": "2025-07-16 10:30:00",
        "php_version": "7.4.33",
        "cache_status": "writable",
        "log_status": "writable"
    }
}
```

### 3. 测试商品接口
访问：`http://your-domain.com/dataoke-service/api/goods?page=1&pageSize=5`

应该返回商品列表数据。

## 📱 小程序端集成

### 1. 复制请求文件
将 `小程序端集成代码/dataoke-request.js` 复制到小程序项目的 `common/` 目录。

### 2. 修改服务端地址
编辑 `dataoke-request.js`，修改服务端地址：

```javascript
const DATAOKE_CONFIG = {
    // 修改为您的实际服务端地址
    baseUrl: 'http://your-domain.com/dataoke-service/api/',
    timeout: 10000,
    showLoading: true
};
```

### 3. 在页面中使用
```javascript
// 在需要使用的页面中引入
import dataokeApi from '@/common/dataoke-request.js'

// 获取商品列表
const result = await dataokeApi.request.getGoodsList({
    page: 1,
    pageSize: 20,
    minCoupon: 10
});
```

## 🔧 配置说明

### 缓存配置
```php
define('CACHE_CONFIG', [
    'type' => 'file',
    'path' => __DIR__ . '/../cache/',
    'expire' => [
        'goods_list' => 1800,    // 商品列表缓存30分钟
        'goods_detail' => 3600,  // 商品详情缓存1小时
        'category' => 86400,     // 分类缓存24小时
        'search' => 900          // 搜索结果缓存15分钟
    ]
]);
```

### 日志配置
```php
define('LOG_CONFIG', [
    'enable' => true,
    'path' => __DIR__ . '/../logs/',
    'level' => 'info',
    'max_files' => 30   // 保留最近30天的日志
]);
```

## 📊 API接口文档

### 商品列表
```
GET /api/goods
参数：
- page: 页码 (默认1)
- pageSize: 每页数量 (默认20)
- categoryId: 分类ID (可选)
- keyword: 搜索关键词 (可选)
- sort: 排序方式 (可选)
- minCoupon: 最低优惠券面额 (可选)
- tmall: 是否天猫商品 (可选)
```

### 商品详情
```
GET /api/goods?action=detail&id=商品ID
```

### 分类列表
```
GET /api/category
```

### 搜索商品
```
GET /api/search?keyword=关键词&page=1&pageSize=20
```

## 🛠️ 维护和监控

### 查看日志
```bash
# 查看最新日志
tail -f logs/$(date +%Y-%m-%d).log

# 查看错误日志
grep "ERROR" logs/*.log
```

### 清理缓存
```bash
# 手动清理缓存
rm -rf cache/*.cache
```

### 性能监控
- 监控 `cache/` 目录大小
- 监控 `logs/` 目录大小
- 监控API响应时间

## ❗ 常见问题

### 1. 权限错误
```bash
chmod 755 cache/ logs/
chown -R www-data:www-data cache/ logs/
```

### 2. CORS错误
检查 `config/config.php` 中的CORS配置。

### 3. API调用失败
检查大淘客凭证是否正确，查看日志文件。

### 4. 缓存问题
手动清理缓存目录，重启Web服务器。

## 🔒 安全建议

1. **生产环境设置**：
   ```php
   define('ENV_CONFIG', [
       'debug' => false,  // 关闭调试模式
   ]);
   ```

2. **设置具体的CORS域名**
3. **定期更新大淘客SDK**
4. **监控日志文件大小**
5. **设置防火墙规则**

## 📞 技术支持

如果在部署过程中遇到问题，请检查：
1. PHP版本和扩展
2. 目录权限设置
3. Web服务器配置
4. 大淘客API凭证
5. 网络连接状况

---

**部署完成后，您的小程序就可以展示大淘客的优惠商品了！** 🎉
