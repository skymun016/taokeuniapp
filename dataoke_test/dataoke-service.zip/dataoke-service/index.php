<?php
/**
 * 大淘客独立服务端 - 入口文件
 * 提供RESTful API接口供小程序端调用
 */

// 设置错误报告
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 设置时区
date_default_timezone_set('Asia/Shanghai');

// 引入配置文件
require_once __DIR__ . '/config/config.php';

// 引入公共函数
require_once __DIR__ . '/lib/common.php';

// 引入大淘客适配器
require_once __DIR__ . '/lib/DataokeAdapter.php';

// 处理CORS跨域请求
handleCors();

// 获取请求方法和路径
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$query = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);

// 解析查询参数
parse_str($query ?: '', $params);

// 路由处理
try {
    // 动态获取基础路径
    $scriptName = $_SERVER['SCRIPT_NAME'];
    $basePath = dirname($scriptName);

    // 移除基础路径（如果有）
    if ($basePath !== '/' && strpos($path, $basePath) === 0) {
        $path = substr($path, strlen($basePath));
    }

    // 路由分发
    if (strpos($path, '/admin') === 0) {
        // 管理后台路由
        require_once __DIR__ . '/admin/index.php';
    } elseif (strpos($path, '/api/goods') === 0) {
        require_once __DIR__ . '/api/goods.php';
    } elseif (strpos($path, '/api/category') === 0) {
        require_once __DIR__ . '/api/category.php';
    } elseif (strpos($path, '/api/search') === 0) {
        require_once __DIR__ . '/api/search.php';
    } elseif (strpos($path, '/api/promotion') === 0) {
        require_once __DIR__ . '/api/promotion.php';
    } elseif (strpos($path, '/api/test') === 0) {
        require_once __DIR__ . '/api/test.php';
    } elseif ($path === '/' || $path === '/index.php' || $path === '') {
        // 显示API文档
        showApiDoc();
    } else {
        apiResponse(404, 'API接口不存在', null);
    }
    
} catch (Exception $e) {
    // 记录错误日志
    logError('系统异常: ' . $e->getMessage(), $e->getTraceAsString());
    
    // 返回错误响应
    apiResponse(500, '服务器内部错误', null);
}

/**
 * 显示API文档
 */
function showApiDoc() {
    header('Content-Type: text/html; charset=utf-8');
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>大淘客服务端 API 文档</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
            .header { background: #f4f4f4; padding: 20px; border-radius: 5px; margin-bottom: 30px; }
            .endpoint { background: #fff; border: 1px solid #ddd; margin: 20px 0; padding: 20px; border-radius: 5px; }
            .method { display: inline-block; padding: 4px 8px; border-radius: 3px; color: white; font-weight: bold; }
            .get { background: #61affe; }
            .post { background: #49cc90; }
            .code { background: #f8f8f8; padding: 10px; border-radius: 3px; font-family: monospace; }
            .param { margin: 10px 0; }
            .param-name { font-weight: bold; color: #333; }
            .param-desc { color: #666; margin-left: 20px; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🛒 大淘客服务端 API</h1>
            <p>独立的大淘客商品数据服务，为小程序端提供优惠商品信息</p>
            <p><strong>服务状态:</strong> <span style="color: green;">✅ 运行中</span></p>
            <p><strong>API版本:</strong> v1.0</p>
            <p><strong>更新时间:</strong> <?php echo date('Y-m-d H:i:s'); ?></p>
        </div>

        <div class="endpoint">
            <h3><span class="method get">GET</span> /api/goods</h3>
            <p><strong>功能:</strong> 获取商品列表</p>
            <div class="param">
                <div class="param-name">参数:</div>
                <div class="param-desc">• page: 页码 (默认1)</div>
                <div class="param-desc">• pageSize: 每页数量 (默认20)</div>
                <div class="param-desc">• categoryId: 分类ID (可选)</div>
                <div class="param-desc">• keyword: 搜索关键词 (可选)</div>
                <div class="param-desc">• sort: 排序方式 (可选: 0-综合, 2-销量, 4-佣金)</div>
                <div class="param-desc">• minCoupon: 最低优惠券面额 (可选)</div>
            </div>
            <div class="code">
                示例: /api/goods?page=1&pageSize=10&minCoupon=10
            </div>
        </div>

        <div class="endpoint">
            <h3><span class="method get">GET</span> /api/goods?action=detail</h3>
            <p><strong>功能:</strong> 获取商品详情</p>
            <div class="param">
                <div class="param-name">参数:</div>
                <div class="param-desc">• id: 商品ID (必填)</div>
            </div>
            <div class="code">
                示例: /api/goods?action=detail&id=123456789
            </div>
        </div>

        <div class="endpoint">
            <h3><span class="method get">GET</span> /api/category</h3>
            <p><strong>功能:</strong> 获取商品分类列表</p>
            <div class="code">
                示例: /api/category
            </div>
        </div>

        <div class="endpoint">
            <h3><span class="method get">GET</span> /api/search</h3>
            <p><strong>功能:</strong> 搜索商品</p>
            <div class="param">
                <div class="param-name">参数:</div>
                <div class="param-desc">• keyword: 搜索关键词 (必填)</div>
                <div class="param-desc">• page: 页码 (默认1)</div>
                <div class="param-desc">• pageSize: 每页数量 (默认20)</div>
            </div>
            <div class="code">
                示例: /api/search?keyword=手机&page=1&pageSize=10
            </div>
        </div>

        <div class="endpoint">
            <h3><span class="method get">GET</span> /api/promotion</h3>
            <p><strong>功能:</strong> 推广相关功能</p>
            <div class="param">
                <div class="param-name">淘口令生成:</div>
                <div class="param-desc">• action=tkl</div>
                <div class="param-desc">• text: 淘口令文本 (必填)</div>
                <div class="param-desc">• url: 商品链接 (必填)</div>
            </div>
            <div class="param">
                <div class="param-name">推广链接生成:</div>
                <div class="param-desc">• action=link</div>
                <div class="param-desc">• goodsId: 商品ID (必填)</div>
                <div class="param-desc">• couponId: 优惠券ID (可选)</div>
                <div class="param-desc">• channelId: 渠道ID (默认common)</div>
            </div>
            <div class="code">
                示例: /api/promotion?action=tkl&text=商品标题&url=商品链接<br>
                示例: /api/promotion?action=link&goodsId=123456&couponId=789
            </div>
        </div>

        <div class="endpoint">
            <h3><span class="method get">GET</span> /api/test</h3>
            <p><strong>功能:</strong> 测试服务连接状态</p>
            <div class="code">
                示例: /api/test
            </div>
        </div>

        <div class="endpoint">
            <h3>📋 返回格式</h3>
            <div class="code">
{<br>
&nbsp;&nbsp;"code": 0,<br>
&nbsp;&nbsp;"message": "success",<br>
&nbsp;&nbsp;"data": {<br>
&nbsp;&nbsp;&nbsp;&nbsp;"list": [...],<br>
&nbsp;&nbsp;&nbsp;&nbsp;"total": 100,<br>
&nbsp;&nbsp;&nbsp;&nbsp;"page": 1,<br>
&nbsp;&nbsp;&nbsp;&nbsp;"pageSize": 20<br>
&nbsp;&nbsp;}<br>
}
            </div>
        </div>

        <div class="endpoint">
            <h3>🔧 错误码说明</h3>
            <div class="param-desc">• 0: 成功</div>
            <div class="param-desc">• 400: 参数错误</div>
            <div class="param-desc">• 404: 接口不存在</div>
            <div class="param-desc">• 500: 服务器错误</div>
        </div>
    </body>
    </html>
    <?php
    exit;
}
?>
