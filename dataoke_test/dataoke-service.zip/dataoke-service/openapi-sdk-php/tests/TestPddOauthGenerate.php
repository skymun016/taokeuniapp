<?php
include './vendor/autoload.php';

// 拼多多-授权备案-创建
$client = new PddOauthGenerate();

$client->setAppKey('xxxxxxxxx');
$client->setAppSecret('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
$client->setVersion('v2.0.0');

$params = [
    "p_id_list" => '8978575_232157258', // 推广位，仅支持单个推广位
    "custom_parameters" => '{"uid":"11111","sid":"22222"}', // 自定义参数
];

$res = $client->setParams($params)->request();
var_dump($res);