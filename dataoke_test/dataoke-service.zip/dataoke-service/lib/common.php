<?php
/**
 * 公共函数库
 */

/**
 * 处理CORS跨域请求
 */
function handleCors() {
    $config = CORS_CONFIG;
    
    // 设置CORS头
    header('Access-Control-Allow-Origin: ' . $config['allow_origin']);
    header('Access-Control-Allow-Methods: ' . $config['allow_methods']);
    header('Access-Control-Allow-Headers: ' . $config['allow_headers']);
    header('Access-Control-Allow-Credentials: ' . $config['allow_credentials']);
    
    // 处理预检请求
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit;
    }
}

/**
 * 统一API响应格式
 * @param int $code 状态码
 * @param string $message 消息
 * @param mixed $data 数据
 */
function apiResponse($code, $message, $data = null) {
    header('Content-Type: application/json; charset=utf-8');
    
    $response = [
        'code' => $code,
        'message' => $message,
        'timestamp' => time()
    ];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * 获取请求参数
 * @param string $key 参数名
 * @param mixed $default 默认值
 * @param string $type 参数类型 (string, int, float, bool)
 * @return mixed
 */
function getParam($key, $default = null, $type = 'string') {
    $value = $_GET[$key] ?? $_POST[$key] ?? $default;
    
    switch ($type) {
        case 'int':
            return (int)$value;
        case 'float':
            return (float)$value;
        case 'bool':
            return (bool)$value;
        case 'array':
            return is_array($value) ? $value : [];
        default:
            return (string)$value;
    }
}

/**
 * 验证必需参数
 * @param array $required 必需参数列表
 * @return bool
 */
function validateRequired($required) {
    foreach ($required as $param) {
        if (empty(getParam($param))) {
            apiResponse(400, "缺少必需参数: {$param}");
            return false;
        }
    }
    return true;
}

/**
 * 缓存操作类
 */
class SimpleCache {
    private $cachePath;
    
    public function __construct() {
        $this->cachePath = CACHE_CONFIG['path'];
    }
    
    /**
     * 获取缓存
     * @param string $key 缓存键
     * @return mixed|null
     */
    public function get($key) {
        $file = $this->cachePath . md5($key) . '.cache';
        
        if (!file_exists($file)) {
            return null;
        }
        
        $data = file_get_contents($file);
        $cache = json_decode($data, true);
        
        if (!$cache || $cache['expire'] < time()) {
            @unlink($file);
            return null;
        }
        
        return $cache['data'];
    }
    
    /**
     * 设置缓存
     * @param string $key 缓存键
     * @param mixed $data 缓存数据
     * @param int $expire 过期时间（秒）
     */
    public function set($key, $data, $expire = 3600) {
        $file = $this->cachePath . md5($key) . '.cache';
        
        $cache = [
            'data' => $data,
            'expire' => time() + $expire,
            'created' => time()
        ];
        
        file_put_contents($file, json_encode($cache, JSON_UNESCAPED_UNICODE));
    }
    
    /**
     * 删除缓存
     * @param string $key 缓存键
     */
    public function delete($key) {
        $file = $this->cachePath . md5($key) . '.cache';
        @unlink($file);
    }
    
    /**
     * 清空所有缓存
     */
    public function clear() {
        $files = glob($this->cachePath . '*.cache');
        foreach ($files as $file) {
            @unlink($file);
        }
    }
}

/**
 * 记录日志
 * @param string $level 日志级别
 * @param string $message 日志消息
 * @param array $context 上下文数据
 */
function writeLog($level, $message, $context = []) {
    if (!LOG_CONFIG['enable']) {
        return;
    }
    
    $logFile = LOG_CONFIG['path'] . date('Y-m-d') . '.log';
    $timestamp = date('Y-m-d H:i:s');
    $contextStr = $context ? ' ' . json_encode($context, JSON_UNESCAPED_UNICODE) : '';
    
    $logEntry = "[{$timestamp}] [{$level}] {$message}{$contextStr}" . PHP_EOL;
    
    file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
}

/**
 * 记录错误日志
 * @param string $message 错误消息
 * @param string $trace 错误堆栈
 */
function logError($message, $trace = '') {
    writeLog('ERROR', $message, ['trace' => $trace]);
}

/**
 * 记录信息日志
 * @param string $message 信息消息
 * @param array $context 上下文
 */
function logInfo($message, $context = []) {
    writeLog('INFO', $message, $context);
}

/**
 * 数据格式转换
 * @param array $data 原始数据
 * @param string $type 转换类型 (goods, category)
 * @return array
 */
function convertData($data, $type) {
    if (!isset(DATA_MAPPING[$type])) {
        return $data;
    }
    
    $mapping = DATA_MAPPING[$type];
    $result = [];
    
    if (isset($data[0])) {
        // 数组数据
        foreach ($data as $item) {
            $result[] = convertSingleData($item, $mapping);
        }
    } else {
        // 单个数据
        $result = convertSingleData($data, $mapping);
    }
    
    return $result;
}

/**
 * 转换单个数据项
 * @param array $item 数据项
 * @param array $mapping 映射关系
 * @return array
 */
function convertSingleData($item, $mapping) {
    $result = [];
    
    foreach ($mapping as $newKey => $oldKey) {
        $result[$newKey] = $item[$oldKey] ?? '';
    }
    
    // 添加一些计算字段
    if (isset($result['price']) && isset($result['original_price'])) {
        $result['discount'] = $result['original_price'] > 0 ? 
            round(($result['original_price'] - $result['price']) / $result['original_price'] * 100, 1) : 0;
    }
    
    return $result;
}

/**
 * 获取大淘客适配器实例
 * @return DataokeAdapter
 */
function getDataokeAdapter() {
    static $adapter = null;
    
    if ($adapter === null) {
        $config = DATAOKE_CONFIG;
        $adapter = new DataokeAdapter(
            $config['app_key'],
            $config['app_secret'],
            $config['pid'],
            $config['version']
        );
    }
    
    return $adapter;
}

/**
 * 清理过期缓存文件
 */
function cleanExpiredCache() {
    $cachePath = CACHE_CONFIG['path'];
    $files = glob($cachePath . '*.cache');
    $cleaned = 0;
    
    foreach ($files as $file) {
        $data = file_get_contents($file);
        $cache = json_decode($data, true);
        
        if (!$cache || $cache['expire'] < time()) {
            @unlink($file);
            $cleaned++;
        }
    }
    
    if ($cleaned > 0) {
        logInfo("清理过期缓存文件: {$cleaned} 个");
    }
}

/**
 * 清理过期日志文件
 */
function cleanExpiredLogs() {
    $logPath = LOG_CONFIG['path'];
    $maxFiles = LOG_CONFIG['max_files'];
    $files = glob($logPath . '*.log');
    
    if (count($files) > $maxFiles) {
        // 按修改时间排序
        usort($files, function($a, $b) {
            return filemtime($a) - filemtime($b);
        });
        
        // 删除最旧的文件
        $toDelete = array_slice($files, 0, count($files) - $maxFiles);
        foreach ($toDelete as $file) {
            @unlink($file);
        }
        
        logInfo("清理过期日志文件: " . count($toDelete) . " 个");
    }
}

// 定期清理任务（10%概率执行）
if (rand(1, 100) <= 10) {
    cleanExpiredCache();
    cleanExpiredLogs();
}
?>
