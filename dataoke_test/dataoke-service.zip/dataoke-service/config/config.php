<?php
/**
 * 大淘客服务端配置文件
 */

// 大淘客API配置
define('DATAOKE_CONFIG', [
    'app_key' => '68768ef94834a',
    'app_secret' => 'f5a5707c8d7b69b8dbad1ec15506c3b1',
    'pid' => 'mm_52162983_39758207_72877900030',
    'version' => 'v1.2.4'
]);

// 缓存配置
define('CACHE_CONFIG', [
    'type' => 'file',  // file, redis (暂时只支持文件缓存)
    'path' => __DIR__ . '/../cache/',
    'expire' => [
        'goods_list' => 1800,    // 商品列表缓存30分钟
        'goods_detail' => 3600,  // 商品详情缓存1小时
        'category' => 86400,     // 分类缓存24小时
        'search' => 900          // 搜索结果缓存15分钟
    ]
]);

// CORS跨域配置
define('CORS_CONFIG', [
    'allow_origin' => '*',  // 允许的域名，生产环境建议设置具体域名
    'allow_methods' => 'GET, POST, OPTIONS',
    'allow_headers' => 'Content-Type, Authorization, X-Requested-With',
    'allow_credentials' => 'false'
]);

// 日志配置
define('LOG_CONFIG', [
    'enable' => true,
    'path' => __DIR__ . '/../logs/',
    'level' => 'info',  // debug, info, warning, error
    'max_files' => 30   // 保留最近30天的日志
]);

// API响应配置
define('API_CONFIG', [
    'default_page_size' => 20,
    'max_page_size' => 100,
    'timeout' => 30,  // API请求超时时间（秒）
    'retry_times' => 3  // 失败重试次数
]);

// 数据转换映射配置
define('DATA_MAPPING', [
    'goods' => [
        'id' => 'goodsId',
        'name' => 'title',
        'pic' => 'mainPic',
        'price' => 'actualPrice',
        'original_price' => 'originalPrice',
        'coupon_price' => 'couponPrice',
        'coupon_conditions' => 'couponConditions',
        'coupon_link' => 'couponLink',
        'coupon_share' => 'couponShare',
        'item_link' => 'itemLink',
        'sale_count' => 'monthSales',
        'shop_name' => 'shopName',
        'commission_rate' => 'commissionRate',
        'coupon_start_time' => 'couponStartTime',
        'coupon_end_time' => 'couponEndTime',
        'coupon_remain_count' => 'couponRemainCount'
    ],
    'category' => [
        'id' => 'cid',
        'name' => 'cname',
        'pic' => 'cpic'
    ]
]);

// 环境配置
define('ENV_CONFIG', [
    'debug' => true,  // 调试模式，生产环境设为false
    'timezone' => 'Asia/Shanghai',
    'charset' => 'utf-8'
]);

// 创建必要的目录
$dirs = [
    CACHE_CONFIG['path'],
    LOG_CONFIG['path']
];

foreach ($dirs as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}
?>
