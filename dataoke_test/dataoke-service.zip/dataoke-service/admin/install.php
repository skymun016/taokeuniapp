<?php
/**
 * 管理后台安装脚本
 * 用于初始化数据库和配置
 */

// 引入配置文件
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/admin_config.php';
require_once __DIR__ . '/lib/DatabaseAdapter.php';

// 设置错误报告
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 检查是否通过命令行运行
$isCli = php_sapi_name() === 'cli';

if (!$isCli) {
    // Web界面
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>管理后台安装 - <?php echo ADMIN_CONFIG['title']; ?></title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
            .header { text-align: center; margin-bottom: 40px; }
            .step { background: #f5f5f5; padding: 20px; margin: 20px 0; border-radius: 5px; }
            .success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
            .error { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
            .warning { background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; }
            .btn { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
            .btn:hover { background: #0056b3; }
            pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1><?php echo ADMIN_CONFIG['title']; ?> - 安装向导</h1>
            <p>欢迎使用大淘客管理后台安装向导</p>
        </div>
        
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = $_POST['action'] ?? '';
            
            if ($action === 'install') {
                performInstallation();
            } elseif ($action === 'test_db') {
                testDatabaseConnection();
            }
        } else {
            showInstallForm();
        }
        ?>
    </body>
    </html>
    <?php
} else {
    // 命令行模式
    echo "大淘客管理后台安装脚本\n";
    echo "=======================\n\n";
    
    performInstallation();
}

/**
 * 显示安装表单
 */
function showInstallForm()
{
    ?>
    <div class="step">
        <h2>📋 安装前检查</h2>
        <?php
        $checks = performPreInstallCheck();
        foreach ($checks as $check) {
            $class = $check['status'] ? 'success' : 'error';
            echo "<div class='$class'>{$check['message']}</div>";
        }
        ?>
    </div>
    
    <div class="step">
        <h2>🔧 数据库配置</h2>
        <form method="POST">
            <input type="hidden" name="action" value="test_db">
            <p>请确认数据库配置正确：</p>
            <pre><?php echo file_get_contents(__DIR__ . '/../config/database.php'); ?></pre>
            <button type="submit" class="btn">测试数据库连接</button>
        </form>
    </div>
    
    <div class="step">
        <h2>🚀 开始安装</h2>
        <form method="POST">
            <input type="hidden" name="action" value="install">
            <p>点击下面的按钮开始安装管理后台：</p>
            <ul>
                <li>创建数据库表结构</li>
                <li>插入默认配置数据</li>
                <li>创建默认管理员账户</li>
                <li>设置必要的权限</li>
            </ul>
            <button type="submit" class="btn">开始安装</button>
        </form>
    </div>
    <?php
}

/**
 * 执行安装前检查
 */
function performPreInstallCheck()
{
    $checks = [];
    
    // 检查PHP版本
    $checks[] = [
        'status' => version_compare(PHP_VERSION, '7.4.0', '>='),
        'message' => 'PHP版本: ' . PHP_VERSION . (version_compare(PHP_VERSION, '7.4.0', '>=') ? ' ✓' : ' ✗ (需要7.4+)')
    ];
    
    // 检查PDO扩展
    $checks[] = [
        'status' => extension_loaded('pdo'),
        'message' => 'PDO扩展: ' . (extension_loaded('pdo') ? '已安装 ✓' : '未安装 ✗')
    ];
    
    // 检查PDO MySQL扩展
    $checks[] = [
        'status' => extension_loaded('pdo_mysql'),
        'message' => 'PDO MySQL扩展: ' . (extension_loaded('pdo_mysql') ? '已安装 ✓' : '未安装 ✗')
    ];
    
    // 检查目录权限
    $dataDir = __DIR__ . '/../data';
    $writable = is_writable(dirname($dataDir));
    $checks[] = [
        'status' => $writable,
        'message' => '数据目录权限: ' . ($writable ? '可写 ✓' : '不可写 ✗')
    ];
    
    // 检查配置文件
    $configExists = file_exists(__DIR__ . '/../config/database.php');
    $checks[] = [
        'status' => $configExists,
        'message' => '数据库配置文件: ' . ($configExists ? '存在 ✓' : '不存在 ✗')
    ];
    
    return $checks;
}

/**
 * 测试数据库连接
 */
function testDatabaseConnection()
{
    try {
        $db = DatabaseAdapter::getInstance();
        $status = $db->getStatus();
        
        if ($status['connected']) {
            echo "<div class='success'>✓ 数据库连接成功！<br>";
            echo "数据库版本: {$status['version']}<br>";
            echo "现有表数量: {$status['tables_count']}</div>";
        } else {
            echo "<div class='error'>✗ 数据库连接失败：{$status['message']}</div>";
        }
    } catch (Exception $e) {
        echo "<div class='error'>✗ 数据库连接异常：" . $e->getMessage() . "</div>";
    }
}

/**
 * 执行安装
 */
function performInstallation()
{
    global $isCli;
    
    $steps = [
        '检查环境' => 'checkEnvironment',
        '连接数据库' => 'connectDatabase',
        '创建数据表' => 'createTables',
        '插入初始数据' => 'insertInitialData',
        '设置权限' => 'setPermissions',
        '完成安装' => 'finishInstallation'
    ];
    
    foreach ($steps as $stepName => $stepFunction) {
        if (!$isCli) echo "<div class='step'><h3>$stepName</h3>";
        else echo "执行步骤: $stepName\n";
        
        try {
            $result = call_user_func($stepFunction);
            
            if ($result['success']) {
                $message = "✓ " . $result['message'];
                if (!$isCli) echo "<div class='success'>$message</div>";
                else echo "$message\n";
            } else {
                $message = "✗ " . $result['message'];
                if (!$isCli) echo "<div class='error'>$message</div>";
                else echo "$message\n";
                break;
            }
        } catch (Exception $e) {
            $message = "✗ 步骤失败: " . $e->getMessage();
            if (!$isCli) echo "<div class='error'>$message</div>";
            else echo "$message\n";
            break;
        }
        
        if (!$isCli) echo "</div>";
    }
}

/**
 * 检查环境
 */
function checkEnvironment()
{
    $checks = performPreInstallCheck();
    $allPassed = true;
    
    foreach ($checks as $check) {
        if (!$check['status']) {
            $allPassed = false;
            break;
        }
    }
    
    return [
        'success' => $allPassed,
        'message' => $allPassed ? '环境检查通过' : '环境检查失败，请检查上述问题'
    ];
}

/**
 * 连接数据库
 */
function connectDatabase()
{
    try {
        $db = DatabaseAdapter::getInstance();
        $status = $db->getStatus();
        
        return [
            'success' => $status['connected'],
            'message' => $status['connected'] ? '数据库连接成功' : $status['message']
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => '数据库连接失败: ' . $e->getMessage()
        ];
    }
}

/**
 * 创建数据表
 */
function createTables()
{
    try {
        $db = DatabaseAdapter::getInstance();

        // 1. 创建管理后台表
        $adminResult = $db->initializeTables();
        if (!$adminResult) {
            return [
                'success' => false,
                'message' => '管理后台数据表创建失败'
            ];
        }

        // 2. 创建大淘客商品数据表（可选）
        $goodsSchemaFile = __DIR__ . '/../../database/dataoke_schema.sql';
        if (file_exists($goodsSchemaFile)) {
            try {
                $sql = file_get_contents($goodsSchemaFile);

                // 分割SQL语句
                $statements = array_filter(
                    array_map('trim', explode(';', $sql)),
                    function($stmt) {
                        return !empty($stmt) && !preg_match('/^--/', $stmt);
                    }
                );

                $db->beginTransaction();

                foreach ($statements as $statement) {
                    if (!empty($statement)) {
                        $db->getPdo()->exec($statement);
                    }
                }

                $db->commit();
            } catch (Exception $e) {
                $db->rollback();
                // 商品表创建失败不影响管理后台功能
                error_log('商品数据表创建失败: ' . $e->getMessage());
            }
        }

        return [
            'success' => true,
            'message' => '数据表创建成功（包含管理后台表和商品数据表）'
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => '创建数据表时出错: ' . $e->getMessage()
        ];
    }
}

/**
 * 插入初始数据
 */
function insertInitialData()
{
    // 初始数据已在SQL文件中定义
    return [
        'success' => true,
        'message' => '初始数据插入完成'
    ];
}

/**
 * 设置权限
 */
function setPermissions()
{
    try {
        $dataDir = __DIR__ . '/../data';
        if (!is_dir($dataDir)) {
            mkdir($dataDir, 0755, true);
        }
        
        $cacheDir = __DIR__ . '/../cache';
        if (!is_dir($cacheDir)) {
            mkdir($cacheDir, 0755, true);
        }
        
        $logsDir = __DIR__ . '/../logs';
        if (!is_dir($logsDir)) {
            mkdir($logsDir, 0755, true);
        }
        
        return [
            'success' => true,
            'message' => '目录权限设置完成'
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => '设置权限失败: ' . $e->getMessage()
        ];
    }
}

/**
 * 完成安装
 */
function finishInstallation()
{
    global $isCli;
    
    $message = "安装完成！\n\n";
    $message .= "访问地址: http://your-domain.com/dataoke-service/admin/\n";
    $message .= "默认账户: admin\n";
    $message .= "默认密码: admin123\n\n";
    $message .= "请立即登录并修改默认密码！";
    
    if (!$isCli) {
        $message = nl2br($message);
    }
    
    return [
        'success' => true,
        'message' => $message
    ];
}
?>
