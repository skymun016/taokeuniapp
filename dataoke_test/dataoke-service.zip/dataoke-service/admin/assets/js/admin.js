/**
 * 大淘客管理后台JavaScript
 */

// 全局变量
let loadingOverlay = null;
let messageContainer = null;

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    initializeAdmin();
});

/**
 * 初始化管理后台
 */
function initializeAdmin() {
    createLoadingOverlay();
    createMessageContainer();
    initializeModals();
    initializeTooltips();
    
    // 检查session超时
    checkSessionTimeout();
    setInterval(checkSessionTimeout, 60000); // 每分钟检查一次
}

/**
 * 创建加载遮罩层
 */
function createLoadingOverlay() {
    loadingOverlay = document.createElement('div');
    loadingOverlay.className = 'loading-overlay';
    loadingOverlay.innerHTML = `
        <div class="loading-content">
            <div class="loading-spinner"></div>
            <div class="loading-text">加载中...</div>
        </div>
    `;
    
    // 添加样式
    const style = document.createElement('style');
    style.textContent = `
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }
        .loading-overlay.show {
            display: flex;
        }
        .loading-content {
            background: white;
            padding: 30px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }
        .loading-spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #007bff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 15px;
        }
        .loading-text {
            font-size: 14px;
            color: #333;
        }
    `;
    document.head.appendChild(style);
    document.body.appendChild(loadingOverlay);
}

/**
 * 创建消息容器
 */
function createMessageContainer() {
    messageContainer = document.createElement('div');
    messageContainer.className = 'message-container';
    
    // 添加样式
    const style = document.createElement('style');
    style.textContent = `
        .message-container {
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 9998;
            max-width: 400px;
        }
        .message-item {
            background: white;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            margin-bottom: 10px;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            transform: translateX(100%);
            transition: transform 0.3s ease;
        }
        .message-item.show {
            transform: translateX(0);
        }
        .message-item.success {
            border-left: 4px solid #28a745;
        }
        .message-item.error {
            border-left: 4px solid #dc3545;
        }
        .message-item.warning {
            border-left: 4px solid #ffc107;
        }
        .message-item.info {
            border-left: 4px solid #17a2b8;
        }
        .message-icon {
            font-size: 18px;
        }
        .message-icon.success { color: #28a745; }
        .message-icon.error { color: #dc3545; }
        .message-icon.warning { color: #ffc107; }
        .message-icon.info { color: #17a2b8; }
        .message-text {
            flex: 1;
            font-size: 14px;
            color: #333;
        }
        .message-close {
            background: none;
            border: none;
            font-size: 16px;
            cursor: pointer;
            color: #999;
            padding: 0;
        }
    `;
    document.head.appendChild(style);
    document.body.appendChild(messageContainer);
}

/**
 * 显示加载状态
 */
function showLoading(text = '加载中...') {
    if (loadingOverlay) {
        loadingOverlay.querySelector('.loading-text').textContent = text;
        loadingOverlay.classList.add('show');
    }
}

/**
 * 隐藏加载状态
 */
function hideLoading() {
    if (loadingOverlay) {
        loadingOverlay.classList.remove('show');
    }
}

/**
 * 显示消息
 */
function showMessage(text, type = 'info', duration = 5000) {
    if (!messageContainer) return;
    
    const messageItem = document.createElement('div');
    messageItem.className = `message-item ${type}`;
    
    const iconMap = {
        success: '✓',
        error: '✗',
        warning: '⚠',
        info: 'ℹ'
    };
    
    messageItem.innerHTML = `
        <div class="message-icon ${type}">${iconMap[type] || 'ℹ'}</div>
        <div class="message-text">${text}</div>
        <button class="message-close" onclick="closeMessage(this)">×</button>
    `;
    
    messageContainer.appendChild(messageItem);
    
    // 显示动画
    setTimeout(() => {
        messageItem.classList.add('show');
    }, 100);
    
    // 自动关闭
    if (duration > 0) {
        setTimeout(() => {
            closeMessage(messageItem.querySelector('.message-close'));
        }, duration);
    }
}

/**
 * 关闭消息
 */
function closeMessage(button) {
    const messageItem = button.closest('.message-item');
    if (messageItem) {
        messageItem.classList.remove('show');
        setTimeout(() => {
            messageItem.remove();
        }, 300);
    }
}

/**
 * 初始化模态框
 */
function initializeModals() {
    // 点击遮罩层关闭模态框
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            closeModal(e.target.id);
        }
    });
    
    // ESC键关闭模态框
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const openModal = document.querySelector('.modal.show');
            if (openModal) {
                closeModal(openModal.id);
            }
        }
    });
}

/**
 * 显示模态框
 */
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
}

/**
 * 关闭模态框
 */
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
    }
}

/**
 * 初始化工具提示
 */
function initializeTooltips() {
    // 简单的工具提示实现
    document.addEventListener('mouseover', function(e) {
        const element = e.target.closest('[title]');
        if (element && element.title) {
            showTooltip(element, element.title);
        }
    });
    
    document.addEventListener('mouseout', function(e) {
        const element = e.target.closest('[title]');
        if (element) {
            hideTooltip();
        }
    });
}

/**
 * 显示工具提示
 */
function showTooltip(element, text) {
    // 简单实现，可以根据需要扩展
    element.setAttribute('data-original-title', element.title);
    element.title = '';
}

/**
 * 隐藏工具提示
 */
function hideTooltip() {
    const elements = document.querySelectorAll('[data-original-title]');
    elements.forEach(element => {
        element.title = element.getAttribute('data-original-title');
        element.removeAttribute('data-original-title');
    });
}

/**
 * 检查Session超时
 */
function checkSessionTimeout() {
    // 这里可以通过AJAX检查session状态
    // 如果session过期，重定向到登录页面
}

/**
 * 格式化文件大小
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * 格式化数字
 */
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/**
 * 格式化日期
 */
function formatDate(date, format = 'YYYY-MM-DD HH:mm:ss') {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const seconds = String(d.getSeconds()).padStart(2, '0');
    
    return format
        .replace('YYYY', year)
        .replace('MM', month)
        .replace('DD', day)
        .replace('HH', hours)
        .replace('mm', minutes)
        .replace('ss', seconds);
}

/**
 * 防抖函数
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * 节流函数
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// 导出全局函数
window.showLoading = showLoading;
window.hideLoading = hideLoading;
window.showMessage = showMessage;
window.closeMessage = closeMessage;
window.showModal = showModal;
window.closeModal = closeModal;
window.formatFileSize = formatFileSize;
window.formatNumber = formatNumber;
window.formatDate = formatDate;
window.debounce = debounce;
window.throttle = throttle;
