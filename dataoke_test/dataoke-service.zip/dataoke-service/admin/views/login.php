<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录 - <?php echo ADMIN_CONFIG['title']; ?></title>
    <link rel="stylesheet" href="<?php echo getAssetsBaseUrl(); ?>/css/admin.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <h1><?php echo ADMIN_CONFIG['title']; ?></h1>
                <p>管理员登录</p>
            </div>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error">
                    <i class="icon-alert-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="login-form">
                <div class="form-group">
                    <label for="username">用户名</label>
                    <input type="text" id="username" name="username" required 
                           value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                           placeholder="请输入用户名">
                </div>
                
                <div class="form-group">
                    <label for="password">密码</label>
                    <input type="password" id="password" name="password" required 
                           placeholder="请输入密码">
                </div>
                
                <div class="form-group checkbox-group">
                    <label>
                        <input type="checkbox" name="remember" value="1">
                        <span class="checkmark"></span>
                        记住登录状态
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="icon-log-in"></i>
                    登录
                </button>
            </form>
            
            <div class="login-footer">
                <p>默认账户：admin / admin123</p>
                <p class="version">版本 <?php echo ADMIN_CONFIG['version']; ?></p>
            </div>
        </div>
    </div>
    
    <script src="<?php echo getAssetsBaseUrl(); ?>/js/admin.js"></script>
    <script>
        // 登录页面特定脚本
        document.addEventListener('DOMContentLoaded', function() {
            // 自动聚焦到用户名输入框
            const usernameInput = document.getElementById('username');
            if (usernameInput && !usernameInput.value) {
                usernameInput.focus();
            } else {
                document.getElementById('password').focus();
            }
            
            // 回车键提交表单
            document.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    document.querySelector('.login-form').submit();
                }
            });
        });
    </script>
</body>
</html>
