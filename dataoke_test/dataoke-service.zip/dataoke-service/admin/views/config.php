<?php
$auth = AdminAuth::getInstance();
$canEdit = $auth->hasPermission('config_edit');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>配置管理 - <?php echo ADMIN_CONFIG['title']; ?></title>
    <link rel="stylesheet" href="<?php echo getAssetsBaseUrl(); ?>/css/admin.css">
</head>
<body>
    <?php include __DIR__ . '/layout/header.php'; ?>
    
    <div class="admin-container">
        <?php include __DIR__ . '/layout/sidebar.php'; ?>
        
        <main class="admin-main">
            <div class="page-header">
                <h1>配置管理</h1>
                <p>管理大淘客API配置、缓存设置和CORS配置</p>
            </div>
            
            <?php if (isset($message)): ?>
                <div class="alert alert-success">
                    <i class="icon-check-circle"></i>
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error">
                    <i class="icon-alert-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <!-- 大淘客配置 -->
            <div class="config-section">
                <div class="section-header">
                    <h2>大淘客API配置</h2>
                    <div class="section-actions">
                        <button onclick="testDataokeConnection()" class="btn btn-info">
                            <i class="icon-wifi"></i>
                            测试连接
                        </button>
                    </div>
                </div>
                
                <form method="POST" class="config-form">
                    <input type="hidden" name="action" value="update_dataoke">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="app_key">App Key</label>
                            <input type="text" id="app_key" name="app_key" 
                                   value="<?php echo htmlspecialchars($dataokeConfig['app_key']); ?>"
                                   <?php echo $canEdit ? '' : 'readonly'; ?> required>
                        </div>
                        
                        <div class="form-group">
                            <label for="app_secret">App Secret</label>
                            <input type="password" id="app_secret" name="app_secret" 
                                   value="<?php echo htmlspecialchars($dataokeConfig['app_secret']); ?>"
                                   <?php echo $canEdit ? '' : 'readonly'; ?> required>
                            <button type="button" onclick="togglePassword('app_secret')" class="password-toggle">
                                <i class="icon-eye"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="pid">推广位PID</label>
                            <input type="text" id="pid" name="pid" 
                                   value="<?php echo htmlspecialchars($dataokeConfig['pid']); ?>"
                                   <?php echo $canEdit ? '' : 'readonly'; ?> required>
                        </div>
                        
                        <div class="form-group">
                            <label for="version">API版本</label>
                            <select id="version" name="version" <?php echo $canEdit ? '' : 'disabled'; ?>>
                                <option value="v1.2.4" <?php echo $dataokeConfig['version'] === 'v1.2.4' ? 'selected' : ''; ?>>v1.2.4</option>
                                <option value="v1.2.3" <?php echo $dataokeConfig['version'] === 'v1.2.3' ? 'selected' : ''; ?>>v1.2.3</option>
                                <option value="v1.2.2" <?php echo $dataokeConfig['version'] === 'v1.2.2' ? 'selected' : ''; ?>>v1.2.2</option>
                            </select>
                        </div>
                    </div>
                    
                    <?php if ($canEdit): ?>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="icon-save"></i>
                                保存配置
                            </button>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
            
            <!-- 缓存配置 -->
            <div class="config-section">
                <div class="section-header">
                    <h2>缓存配置</h2>
                </div>
                
                <form method="POST" class="config-form">
                    <input type="hidden" name="action" value="update_cache">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="cache_type">缓存类型</label>
                            <select id="cache_type" name="type" <?php echo $canEdit ? '' : 'disabled'; ?>>
                                <option value="file" <?php echo $cacheConfig['type'] === 'file' ? 'selected' : ''; ?>>文件缓存</option>
                                <option value="redis" <?php echo $cacheConfig['type'] === 'redis' ? 'selected' : ''; ?>>Redis缓存</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="cache_path">缓存路径</label>
                            <input type="text" id="cache_path" name="path" 
                                   value="<?php echo htmlspecialchars($cacheConfig['path']); ?>"
                                   <?php echo $canEdit ? '' : 'readonly'; ?>>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>缓存过期时间（秒）</label>
                        <div class="cache-expire-grid">
                            <div class="expire-item">
                                <label for="goods_list_expire">商品列表</label>
                                <input type="number" id="goods_list_expire" name="expire[goods_list]" 
                                       value="<?php echo $cacheConfig['expire']['goods_list']; ?>"
                                       <?php echo $canEdit ? '' : 'readonly'; ?> min="0">
                            </div>
                            
                            <div class="expire-item">
                                <label for="goods_detail_expire">商品详情</label>
                                <input type="number" id="goods_detail_expire" name="expire[goods_detail]" 
                                       value="<?php echo $cacheConfig['expire']['goods_detail']; ?>"
                                       <?php echo $canEdit ? '' : 'readonly'; ?> min="0">
                            </div>
                            
                            <div class="expire-item">
                                <label for="category_expire">分类信息</label>
                                <input type="number" id="category_expire" name="expire[category]" 
                                       value="<?php echo $cacheConfig['expire']['category']; ?>"
                                       <?php echo $canEdit ? '' : 'readonly'; ?> min="0">
                            </div>
                            
                            <div class="expire-item">
                                <label for="search_expire">搜索结果</label>
                                <input type="number" id="search_expire" name="expire[search]" 
                                       value="<?php echo $cacheConfig['expire']['search']; ?>"
                                       <?php echo $canEdit ? '' : 'readonly'; ?> min="0">
                            </div>
                        </div>
                    </div>
                    
                    <?php if ($canEdit): ?>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="icon-save"></i>
                                保存配置
                            </button>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
            
            <!-- CORS配置 -->
            <div class="config-section">
                <div class="section-header">
                    <h2>CORS跨域配置</h2>
                </div>
                
                <form method="POST" class="config-form">
                    <input type="hidden" name="action" value="update_cors">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="allow_origin">允许的域名</label>
                            <input type="text" id="allow_origin" name="allow_origin" 
                                   value="<?php echo htmlspecialchars($corsConfig['allow_origin']); ?>"
                                   <?php echo $canEdit ? '' : 'readonly'; ?>
                                   placeholder="* 或具体域名">
                        </div>
                        
                        <div class="form-group">
                            <label for="allow_methods">允许的方法</label>
                            <input type="text" id="allow_methods" name="allow_methods" 
                                   value="<?php echo htmlspecialchars($corsConfig['allow_methods']); ?>"
                                   <?php echo $canEdit ? '' : 'readonly'; ?>>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="allow_headers">允许的头部</label>
                            <input type="text" id="allow_headers" name="allow_headers" 
                                   value="<?php echo htmlspecialchars($corsConfig['allow_headers']); ?>"
                                   <?php echo $canEdit ? '' : 'readonly'; ?>>
                        </div>
                        
                        <div class="form-group">
                            <label for="allow_credentials">允许凭证</label>
                            <select id="allow_credentials" name="allow_credentials" <?php echo $canEdit ? '' : 'disabled'; ?>>
                                <option value="true" <?php echo $corsConfig['allow_credentials'] === 'true' ? 'selected' : ''; ?>>是</option>
                                <option value="false" <?php echo $corsConfig['allow_credentials'] === 'false' ? 'selected' : ''; ?>>否</option>
                            </select>
                        </div>
                    </div>
                    
                    <?php if ($canEdit): ?>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="icon-save"></i>
                                保存配置
                            </button>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </main>
    </div>
    
    <script src="<?php echo getAssetsBaseUrl(); ?>/js/admin.js"></script>
    <script>
        // 配置页面特定脚本
        function togglePassword(fieldId) {
            const field = document.getElementById(fieldId);
            const button = field.nextElementSibling;
            const icon = button.querySelector('i');
            
            if (field.type === 'password') {
                field.type = 'text';
                icon.className = 'icon-eye-off';
            } else {
                field.type = 'password';
                icon.className = 'icon-eye';
            }
        }
        
        function testDataokeConnection() {
            showLoading('正在测试连接...');
            
            const form = new FormData();
            form.append('action', 'test_dataoke');
            
            fetch('<?php echo getAdminBaseUrl(); ?>/config', {
                method: 'POST',
                body: form
            })
            .then(response => response.text())
            .then(html => {
                hideLoading();
                
                // 解析响应中的消息
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const successAlert = doc.querySelector('.alert-success');
                const errorAlert = doc.querySelector('.alert-error');
                
                if (successAlert) {
                    showMessage(successAlert.textContent.trim(), 'success');
                } else if (errorAlert) {
                    showMessage(errorAlert.textContent.trim(), 'error');
                } else {
                    showMessage('测试完成', 'info');
                }
            })
            .catch(error => {
                hideLoading();
                showMessage('测试失败: ' + error.message, 'error');
            });
        }
    </script>
</body>
</html>
