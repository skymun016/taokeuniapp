<?php
$auth = AdminAuth::getInstance();
$user = $auth->getCurrentUser();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>仪表板 - <?php echo ADMIN_CONFIG['title']; ?></title>
    <link rel="stylesheet" href="<?php echo getAssetsBaseUrl(); ?>/css/admin.css">
</head>
<body>
    <?php include __DIR__ . '/layout/header.php'; ?>
    
    <div class="admin-container">
        <?php include __DIR__ . '/layout/sidebar.php'; ?>
        
        <main class="admin-main">
            <div class="page-header">
                <h1>仪表板</h1>
                <p>系统概览和状态监控</p>
            </div>
            
            <!-- 状态卡片 -->
            <div class="status-cards">
                <div class="status-card <?php echo $statusData['dataoke_status'] ? 'success' : 'error'; ?>">
                    <div class="status-icon">
                        <i class="icon-<?php echo $statusData['dataoke_status'] ? 'check-circle' : 'alert-circle'; ?>"></i>
                    </div>
                    <div class="status-content">
                        <h3>大淘客API</h3>
                        <p><?php echo $statusData['dataoke_status'] ? '连接正常' : '连接异常'; ?></p>
                        <small><?php echo htmlspecialchars($statusData['dataoke_message']); ?></small>
                    </div>
                </div>
                
                <div class="status-card info">
                    <div class="status-icon">
                        <i class="icon-database"></i>
                    </div>
                    <div class="status-content">
                        <h3>缓存状态</h3>
                        <p><?php echo $statusData['cache_files']; ?> 个文件</p>
                        <small>总大小: <?php echo $statusData['cache_size']; ?></small>
                    </div>
                </div>
                
                <div class="status-card warning">
                    <div class="status-icon">
                        <i class="icon-file-text"></i>
                    </div>
                    <div class="status-content">
                        <h3>日志文件</h3>
                        <p><?php echo $statusData['log_files']; ?> 个文件</p>
                        <small>总大小: <?php echo $statusData['log_size']; ?></small>
                    </div>
                </div>
                
                <div class="status-card primary">
                    <div class="status-icon">
                        <i class="icon-server"></i>
                    </div>
                    <div class="status-content">
                        <h3>服务器状态</h3>
                        <p>运行正常</p>
                        <small>内存使用: <?php echo $statusData['memory_usage']; ?></small>
                    </div>
                </div>
            </div>
            
            <!-- 快速操作 -->
            <div class="quick-actions">
                <h2>快速操作</h2>
                <div class="action-buttons">
                    <a href="<?php echo getAdminBaseUrl(); ?>/config" class="btn btn-primary">
                        <i class="icon-settings"></i>
                        配置管理
                    </a>
                    <button onclick="clearCache()" class="btn btn-warning">
                        <i class="icon-trash-2"></i>
                        清理缓存
                    </button>
                    <a href="<?php echo getAdminBaseUrl(); ?>/goods" class="btn btn-info">
                        <i class="icon-shopping-cart"></i>
                        商品管理
                    </a>
                    <a href="<?php echo getAdminBaseUrl(); ?>/logs" class="btn btn-secondary">
                        <i class="icon-file-text"></i>
                        查看日志
                    </a>
                </div>
            </div>
            
            <!-- 系统信息 -->
            <div class="system-info">
                <h2>系统信息</h2>
                <div class="info-grid">
                    <div class="info-item">
                        <label>服务器时间</label>
                        <span><?php echo $statusData['server_time']; ?></span>
                    </div>
                    <div class="info-item">
                        <label>PHP版本</label>
                        <span><?php echo $statusData['php_version']; ?></span>
                    </div>
                    <div class="info-item">
                        <label>内存使用</label>
                        <span><?php echo $statusData['memory_usage']; ?></span>
                    </div>
                    <div class="info-item">
                        <label>磁盘空间</label>
                        <span><?php echo $statusData['disk_free']; ?> 可用</span>
                    </div>
                </div>
            </div>
            
            <!-- 最近活动 -->
            <div class="recent-activity">
                <h2>最近活动</h2>
                <div class="activity-list" id="recentActivity">
                    <div class="loading">加载中...</div>
                </div>
            </div>
        </main>
    </div>
    
    <script src="<?php echo getAssetsBaseUrl(); ?>/js/admin.js"></script>
    <script>
        // 仪表板特定脚本
        document.addEventListener('DOMContentLoaded', function() {
            // 加载最近活动
            loadRecentActivity();
            
            // 定时刷新状态
            setInterval(refreshStatus, 30000); // 30秒刷新一次
        });
        
        // 清理缓存
        function clearCache() {
            if (confirm('确定要清理所有缓存文件吗？')) {
                showLoading('正在清理缓存...');
                
                fetch('<?php echo getAdminBaseUrl(); ?>/api/cache/clear', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    hideLoading();
                    if (data.success) {
                        showMessage(data.message, 'success');
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        showMessage(data.message, 'error');
                    }
                })
                .catch(error => {
                    hideLoading();
                    showMessage('清理缓存失败: ' + error.message, 'error');
                });
            }
        }
        
        // 加载最近活动
        function loadRecentActivity() {
            // 这里可以通过AJAX加载最近的操作日志
            const activityList = document.getElementById('recentActivity');
            activityList.innerHTML = `
                <div class="activity-item">
                    <div class="activity-icon success">
                        <i class="icon-log-in"></i>
                    </div>
                    <div class="activity-content">
                        <p><strong><?php echo htmlspecialchars($user['username']); ?></strong> 登录系统</p>
                        <small>刚刚</small>
                    </div>
                </div>
                <div class="activity-item">
                    <div class="activity-icon info">
                        <i class="icon-eye"></i>
                    </div>
                    <div class="activity-content">
                        <p>查看仪表板</p>
                        <small>刚刚</small>
                    </div>
                </div>
            `;
        }
        
        // 刷新状态
        function refreshStatus() {
            fetch('<?php echo getAdminBaseUrl(); ?>/api/status')
                .then(response => response.json())
                .then(data => {
                    // 更新状态显示
                    updateStatusDisplay(data);
                })
                .catch(error => {
                    console.error('刷新状态失败:', error);
                });
        }
        
        // 更新状态显示
        function updateStatusDisplay(data) {
            // 更新大淘客API状态
            const dataokeCard = document.querySelector('.status-card:first-child');
            if (data.dataoke_status) {
                dataokeCard.className = 'status-card success';
                dataokeCard.querySelector('p').textContent = '连接正常';
            } else {
                dataokeCard.className = 'status-card error';
                dataokeCard.querySelector('p').textContent = '连接异常';
            }
            dataokeCard.querySelector('small').textContent = data.dataoke_message;
            
            // 更新其他状态信息
            document.querySelector('.info-item:first-child span').textContent = data.server_time;
            document.querySelector('.info-item:nth-child(3) span').textContent = data.memory_usage;
        }
    </script>
</body>
</html>
