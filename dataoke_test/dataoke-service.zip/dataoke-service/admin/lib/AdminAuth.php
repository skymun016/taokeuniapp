<?php
/**
 * 管理后台认证类
 */

// 引入数据库适配器
require_once __DIR__ . '/DatabaseAdapter.php';

class AdminAuth
{
    private static $instance = null;
    private $db = null;
    private $useDatabase = false;

    /**
     * 获取单例实例
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * 构造函数
     */
    private function __construct()
    {
        // 启动session
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // 初始化数据库连接
        $this->initDatabase();

        // 初始化默认管理员
        $this->initDefaultAdmin();
    }

    /**
     * 初始化数据库连接
     */
    private function initDatabase()
    {
        try {
            $this->db = DatabaseAdapter::getInstance();
            $this->useDatabase = $this->db->isAvailable();

            // 如果数据库可用，检查表是否存在
            if ($this->useDatabase) {
                if (!$this->db->tableExists('dtk_admin_users')) {
                    // 尝试初始化数据库表
                    $this->db->initializeTables();
                }
            }
        } catch (Exception $e) {
            error_log('Database initialization failed: ' . $e->getMessage());
            $this->useDatabase = false;
        }
    }
    
    /**
     * 初始化默认管理员账户
     */
    private function initDefaultAdmin()
    {
        if ($this->useDatabase) {
            // 数据库模式：检查是否存在管理员用户
            try {
                $sql = "SELECT COUNT(*) as count FROM dtk_admin_users WHERE role = 'super_admin'";
                $result = $this->db->fetchOne($sql);

                if ($result['count'] == 0) {
                    // 创建默认管理员
                    $defaultAdmin = [
                        'username' => DEFAULT_ADMIN['username'],
                        'password' => password_hash(DEFAULT_ADMIN['password'], PASSWORD_DEFAULT),
                        'email' => DEFAULT_ADMIN['email'],
                        'role' => DEFAULT_ADMIN['role'],
                        'status' => 'active',
                        'login_count' => 0
                    ];

                    $this->db->insert('dtk_admin_users', $defaultAdmin);
                }
            } catch (Exception $e) {
                error_log('Failed to create default admin: ' . $e->getMessage());
                // 回退到文件模式
                $this->initDefaultAdminFile();
            }
        } else {
            // 文件模式
            $this->initDefaultAdminFile();
        }
    }

    /**
     * 文件模式初始化默认管理员
     */
    private function initDefaultAdminFile()
    {
        if (!file_exists(ADMIN_USERS_FILE)) {
            $defaultAdmin = DEFAULT_ADMIN;
            $defaultAdmin['password'] = password_hash($defaultAdmin['password'], PASSWORD_DEFAULT);
            $defaultAdmin['id'] = 1;
            $defaultAdmin['status'] = 'active';
            $defaultAdmin['last_login'] = null;
            $defaultAdmin['login_count'] = 0;

            $users = [$defaultAdmin];
            file_put_contents(ADMIN_USERS_FILE, json_encode($users, JSON_PRETTY_PRINT));
        }
    }
    
    /**
     * 用户登录
     */
    public function login($username, $password, $remember = false)
    {
        // 检查登录尝试次数
        if ($this->isAccountLocked($username)) {
            return [
                'success' => false,
                'message' => '账户已被锁定，请稍后再试'
            ];
        }
        
        // 获取用户信息
        $user = $this->getUserByUsername($username);
        if (!$user) {
            $this->recordLoginAttempt($username, false);
            return [
                'success' => false,
                'message' => '用户名或密码错误'
            ];
        }
        
        // 验证密码
        if (!password_verify($password, $user['password'])) {
            $this->recordLoginAttempt($username, false);
            return [
                'success' => false,
                'message' => '用户名或密码错误'
            ];
        }
        
        // 检查用户状态
        if ($user['status'] !== 'active') {
            return [
                'success' => false,
                'message' => '账户已被禁用'
            ];
        }
        
        // 登录成功
        $this->recordLoginAttempt($username, true);
        $this->updateUserLoginInfo($user['id']);
        $this->setUserSession($user);
        
        // 记录登录日志
        AdminLogger::getInstance()->log('login', '用户登录成功', [
            'username' => $username,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ]);
        
        return [
            'success' => true,
            'message' => '登录成功',
            'user' => $this->sanitizeUser($user)
        ];
    }
    
    /**
     * 用户登出
     */
    public function logout()
    {
        $user = $this->getCurrentUser();
        if ($user) {
            AdminLogger::getInstance()->log('logout', '用户登出', [
                'username' => $user['username']
            ]);
        }
        
        // 清除session
        session_unset();
        session_destroy();
        
        return ['success' => true, 'message' => '登出成功'];
    }
    
    /**
     * 检查用户是否已登录
     */
    public function isLoggedIn()
    {
        return isset($_SESSION['admin_user']) && !empty($_SESSION['admin_user']);
    }
    
    /**
     * 获取当前登录用户
     */
    public function getCurrentUser()
    {
        if (!$this->isLoggedIn()) {
            return null;
        }
        
        return $_SESSION['admin_user'];
    }
    
    /**
     * 检查用户权限
     */
    public function hasPermission($permission)
    {
        $user = $this->getCurrentUser();
        if (!$user) {
            return false;
        }
        
        $permissions = ADMIN_PERMISSIONS[$user['role']] ?? [];
        return $permissions[$permission] ?? false;
    }
    
    /**
     * 要求登录
     */
    public function requireLogin()
    {
        if (!$this->isLoggedIn()) {
            header('Location: /admin/login');
            exit;
        }
    }
    
    /**
     * 要求权限
     */
    public function requirePermission($permission)
    {
        $this->requireLogin();
        
        if (!$this->hasPermission($permission)) {
            http_response_code(403);
            echo json_encode(['error' => '权限不足']);
            exit;
        }
    }
    
    /**
     * 根据用户名获取用户
     */
    private function getUserByUsername($username)
    {
        if ($this->useDatabase) {
            try {
                $sql = "SELECT * FROM dtk_admin_users WHERE username = :username AND status != 'deleted'";
                return $this->db->fetchOne($sql, ['username' => $username]);
            } catch (Exception $e) {
                error_log('Failed to get user from database: ' . $e->getMessage());
                return $this->getUserByUsernameFile($username);
            }
        } else {
            return $this->getUserByUsernameFile($username);
        }
    }

    /**
     * 文件模式根据用户名获取用户
     */
    private function getUserByUsernameFile($username)
    {
        $users = $this->getAllUsers();
        foreach ($users as $user) {
            if ($user['username'] === $username) {
                return $user;
            }
        }
        return null;
    }

    /**
     * 获取所有用户
     */
    private function getAllUsers()
    {
        if ($this->useDatabase) {
            try {
                $sql = "SELECT * FROM dtk_admin_users WHERE status != 'deleted' ORDER BY created_time DESC";
                return $this->db->fetchAll($sql);
            } catch (Exception $e) {
                error_log('Failed to get users from database: ' . $e->getMessage());
                return $this->getAllUsersFile();
            }
        } else {
            return $this->getAllUsersFile();
        }
    }

    /**
     * 文件模式获取所有用户
     */
    private function getAllUsersFile()
    {
        if (!file_exists(ADMIN_USERS_FILE)) {
            return [];
        }

        $content = file_get_contents(ADMIN_USERS_FILE);
        return json_decode($content, true) ?: [];
    }
    
    /**
     * 设置用户session
     */
    private function setUserSession($user)
    {
        $_SESSION['admin_user'] = $this->sanitizeUser($user);
        $_SESSION['admin_login_time'] = time();
    }
    
    /**
     * 清理用户信息（移除敏感信息）
     */
    private function sanitizeUser($user)
    {
        unset($user['password']);
        return $user;
    }
    
    /**
     * 检查账户是否被锁定
     */
    private function isAccountLocked($username)
    {
        if (!file_exists(LOGIN_ATTEMPTS_FILE)) {
            return false;
        }
        
        $attempts = json_decode(file_get_contents(LOGIN_ATTEMPTS_FILE), true) ?: [];
        $userAttempts = $attempts[$username] ?? [];
        
        if (empty($userAttempts)) {
            return false;
        }
        
        $recentAttempts = array_filter($userAttempts, function($attempt) {
            return (time() - $attempt['time']) < ADMIN_CONFIG['lockout_time'];
        });
        
        $failedAttempts = array_filter($recentAttempts, function($attempt) {
            return !$attempt['success'];
        });
        
        return count($failedAttempts) >= ADMIN_CONFIG['max_login_attempts'];
    }
    
    /**
     * 记录登录尝试
     */
    private function recordLoginAttempt($username, $success)
    {
        if ($this->useDatabase) {
            try {
                $data = [
                    'username' => $username,
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                    'success' => $success ? 1 : 0,
                    'failure_reason' => $success ? null : '用户名或密码错误',
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
                ];

                $this->db->insert('dtk_login_attempts', $data);

                // 清理旧记录（保留最近30天）
                $sql = "DELETE FROM dtk_login_attempts WHERE created_time < DATE_SUB(NOW(), INTERVAL 30 DAY)";
                $this->db->query($sql);
            } catch (Exception $e) {
                error_log('Failed to record login attempt: ' . $e->getMessage());
                $this->recordLoginAttemptFile($username, $success);
            }
        } else {
            $this->recordLoginAttemptFile($username, $success);
        }
    }

    /**
     * 文件模式记录登录尝试
     */
    private function recordLoginAttemptFile($username, $success)
    {
        $attempts = [];
        if (file_exists(LOGIN_ATTEMPTS_FILE)) {
            $attempts = json_decode(file_get_contents(LOGIN_ATTEMPTS_FILE), true) ?: [];
        }

        if (!isset($attempts[$username])) {
            $attempts[$username] = [];
        }

        $attempts[$username][] = [
            'time' => time(),
            'success' => $success,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ];

        // 只保留最近的尝试记录
        $attempts[$username] = array_slice($attempts[$username], -20);

        file_put_contents(LOGIN_ATTEMPTS_FILE, json_encode($attempts, JSON_PRETTY_PRINT));
    }

    /**
     * 更新用户登录信息
     */
    private function updateUserLoginInfo($userId)
    {
        if ($this->useDatabase) {
            try {
                $data = [
                    'last_login' => date('Y-m-d H:i:s'),
                    'login_count' => new PDO_Expression('login_count + 1')
                ];

                // 由于PDO_Expression不存在，我们使用原生SQL
                $sql = "UPDATE dtk_admin_users SET last_login = NOW(), login_count = login_count + 1 WHERE id = :id";
                $this->db->query($sql, ['id' => $userId]);
            } catch (Exception $e) {
                error_log('Failed to update user login info: ' . $e->getMessage());
                $this->updateUserLoginInfoFile($userId);
            }
        } else {
            $this->updateUserLoginInfoFile($userId);
        }
    }

    /**
     * 文件模式更新用户登录信息
     */
    private function updateUserLoginInfoFile($userId)
    {
        $users = $this->getAllUsersFile();
        foreach ($users as &$user) {
            if ($user['id'] == $userId) {
                $user['last_login'] = date('Y-m-d H:i:s');
                $user['login_count'] = ($user['login_count'] ?? 0) + 1;
                break;
            }
        }

        file_put_contents(ADMIN_USERS_FILE, json_encode($users, JSON_PRETTY_PRINT));
    }
}
?>
