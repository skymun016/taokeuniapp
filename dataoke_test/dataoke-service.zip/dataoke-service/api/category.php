<?php
/**
 * 分类相关API接口
 */

// 引入依赖
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/common.php';
require_once __DIR__ . '/../lib/DataokeAdapter.php';

// 只允许GET请求
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    apiResponse(405, '只支持GET请求');
}

// 创建缓存实例
$cache = new SimpleCache();

// 构建缓存键
$cacheKey = 'category_list';

// 尝试从缓存获取
$cachedData = $cache->get($cacheKey);
if ($cachedData !== null) {
    logInfo('分类列表缓存命中');
    apiResponse(0, 'success', $cachedData);
}

try {
    // 获取大淘客适配器
    $adapter = getDataokeAdapter();
    
    // 获取超级分类
    $result = $adapter->getSuperCategory();
    
    if ($result['success']) {
        // 转换数据格式
        $categoryList = convertData($result['data'], 'category');
        
        // 添加默认分类
        $defaultCategories = [
            [
                'id' => '',
                'name' => '全部分类',
                'pic' => ''
            ]
        ];
        
        $responseData = array_merge($defaultCategories, $categoryList);
        
        // 缓存结果
        $cache->set($cacheKey, $responseData, CACHE_CONFIG['expire']['category']);
        
        logInfo('分类列表获取成功', ['count' => count($responseData)]);
        
        apiResponse(0, 'success', $responseData);
    } else {
        logError('分类列表获取失败: ' . $result['message']);
        apiResponse(500, '获取分类列表失败: ' . $result['message']);
    }
    
} catch (Exception $e) {
    logError('分类列表接口异常: ' . $e->getMessage(), $e->getTraceAsString());
    apiResponse(500, '服务器内部错误');
}
?>
